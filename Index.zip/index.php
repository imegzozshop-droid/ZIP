<?php
declare(strict_types=1);

/**
 * OPAL — Single-file digital storefront
 * PHP 8.0+, JSON storage, no database/framework/Composer.
 * Set up the first administrator securely on first run.
 */
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;
session_name('opal_session');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
session_start();
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

$ROOT = __DIR__;
$DATA = $ROOT . '/data';
$UPLOADS = $ROOT . '/uploads';
foreach ([$DATA, $UPLOADS] as $dir) {
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        http_response_code(500); exit('امکان ایجاد پوشه‌های موردنیاز وجود ندارد.');
    }
}
if (!is_file($DATA.'/.htaccess')) @file_put_contents($DATA.'/.htaccess', "Require all denied\nDeny from all\n");
if (!is_file($UPLOADS.'/.htaccess')) @file_put_contents($UPLOADS.'/.htaccess', "Options -Indexes\n<FilesMatch \"\\.(php|php[0-9]?|phtml|phar|cgi|pl|py|sh|html?)$\">\nRequire all denied\nDeny from all\n</FilesMatch>\n");
if (!is_file($DATA.'/index.html')) @file_put_contents($DATA.'/index.html', '');
$FILES = [
 'products'=>$DATA.'/products.json','categories'=>$DATA.'/categories.json','orders'=>$DATA.'/orders.json',
 'users'=>$DATA.'/users.json','settings'=>$DATA.'/settings.json','discounts'=>$DATA.'/discounts.json',
 'events'=>$DATA.'/events.json','messages'=>$DATA.'/messages.json','visits'=>$DATA.'/visits.json'
];
$DEFAULT_SETTINGS = [
 'site_name'=>'Opal','tagline'=>'دنیای دیجیتال Minecraft، با خریدی مطمئن‌تر','description'=>'فروشگاه محصولات دیجیتال Minecraft با تجربه‌ای سریع و ساده.','logo_path'=>'','favicon_path'=>'',
 'about'=>'Opal فروشگاهی برای محصولات دیجیتال مرتبط با Minecraft است. پیش از خرید، توضیحات و شرایط هر محصول را بررسی کنید.',
 'contact_email'=>'','contact_phone'=>'','telegram'=>'','instagram'=>'','rialit_api_key'=>'','rialit_webhook_secret'=>'','payment_enabled'=>'0','payment_mode'=>'normal','payment_callback_url'=>'',
 'currency'=>'تومان','shipping_note'=>'تحویل دیجیتال پس از تأیید پرداخت انجام می‌شود.','seo_title'=>'Opal | فروشگاه محصولات دیجیتال Minecraft',
 'seo_description'=>'محصولات دیجیتال Minecraft را با اطلاعات شفاف و فرایند خرید ساده بررسی کنید.'
];

function opal_json_read(string $file, array $fallback=[]): array {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw)==='') return $fallback;
    $value = json_decode($raw, true);
    return is_array($value) ? $value : $fallback;
}
function opal_json_write(string $file, array $value): void {
    $lock = @fopen($file.'.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX)) { if (is_resource($lock)) fclose($lock); throw new RuntimeException('قفل ذخیره‌سازی در دسترس نیست.'); }
    try {
        $json = json_encode(array_values($value) === $value ? array_values($value) : $value, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE);
        if ($json === false) throw new RuntimeException('تبدیل اطلاعات به JSON ناموفق بود.');
        $tmp = $file.'.tmp.'.bin2hex(random_bytes(5));
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) throw new RuntimeException('ذخیره اطلاعات ممکن نیست.');
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); throw new RuntimeException('ثبت نهایی اطلاعات ناموفق بود.'); }
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
function all_data(string $key): array { global $FILES; return opal_json_read($FILES[$key], []); }
function save_data(string $key, array $data): void { global $FILES; opal_json_write($FILES[$key], $data); }
function settings(): array { global $FILES,$DEFAULT_SETTINGS; return array_merge($DEFAULT_SETTINGS, opal_json_read($FILES['settings'], [])); }
function save_settings(array $s): void { global $FILES,$DEFAULT_SETTINGS; opal_json_write($FILES['settings'], array_merge($DEFAULT_SETTINGS,$s)); }
/** Normalize pasted Rialit credentials without ever exposing them to the browser. */
function rialit_normalize_api_key(string $value): string {
    $value=trim($value);
    $value=preg_replace('/^Bearer\s+/i','',$value) ?? $value;
    return trim($value);
}
/** Read Rialit credentials from the current setting names or server environment. */
function rialit_api_key_value(?array $configured=null): string {
    $configured=$configured ?? settings();
    foreach (['rialit_api_key','rialit_api','rialit_token','rialit_key'] as $name) {
        $value=$configured[$name]??'';
        if (is_string($value) && rialit_normalize_api_key($value)!=='') return rialit_normalize_api_key($value);
    }
    $env=getenv('RIALIT_API_KEY');
    if (is_string($env) && rialit_normalize_api_key($env)!=='') return rialit_normalize_api_key($env);
    return '';
}
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function uid(string $prefix=''): string { return $prefix.bin2hex(random_bytes(10)); }
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void { $sent=$_POST['csrf']??''; if (!is_string($sent)||!hash_equals((string)($_SESSION['csrf']??''),$sent)) throw new RuntimeException('درخواست منقضی شده است؛ صفحه را تازه‌سازی کنید.'); }
function is_admin(): bool { return ($_SESSION['role']??'')==='admin' && !empty($_SESSION['user_id']); }
function is_customer(): bool { return ($_SESSION['role']??'')==='customer' && !empty($_SESSION['user_id']); }
function current_user(): ?array { $id=(string)($_SESSION['user_id']??''); if($id==='')return null; foreach(all_data('users') as $u)if(($u['id']??'')===$id)return $u; return null; }
function redirect(string $url): never { header('Location: '.$url); exit; }
function flash(string $msg, string $type='ok'): void { $_SESSION['flash']=['message'=>$msg,'type'=>$type]; }
function slugify(string $text): string {
    $text=trim(u_lower($text));
    $text=preg_replace('/[^\p{L}\p{N}]+/u','-',$text) ?? '';
    return trim($text,'-') ?: ('item-'.substr(bin2hex(random_bytes(4)),0,8));
}
function money($amount): string { return number_format((int)$amount,0,'.',',').' تومان'; }
function current_url(): string {
    $scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';
    return $scheme.'://'.($_SERVER['HTTP_HOST']??'localhost').strtok($_SERVER['REQUEST_URI']??'/','?');
}
function rialit_webhook_url(?array $configured=null): string {
    $configured=$configured??settings();$secret=(string)($configured['rialit_webhook_secret']??'');
    return current_url().'?page=payment-webhook&key='.rawurlencode($secret);
}
function product_by_id(string $id): ?array { foreach(all_data('products') as $p) if (($p['id']??'')===$id) return $p; return null; }
function public_products(): array { return array_values(array_filter(all_data('products'),fn($p)=>($p['status']??'draft')==='published')); }
function product_price(array $p): int { $price=max(0,(int)($p['price']??0)); $sale=(int)($p['sale_price']??0); return $sale>0&&$sale<$price?$sale:$price; }
function stock_count(array $p): int {
    if (($p['delivery_type']??'manual')==='codes') return count(array_filter($p['codes']??[],fn($c)=>empty($c['used'])&&empty($c['reserved'])));
    return max(0,(int)($p['stock']??0));
}
function log_event(string $event, array $meta=[]): void {
    $rows=all_data('events'); $rows[]=['id'=>uid('evt_'),'event'=>$event,'meta'=>$meta,'at'=>date('c'),'ip_hash'=>hash('sha256',(string)($_SERVER['REMOTE_ADDR']??'').(string)($_SERVER['HTTP_USER_AGENT']??''))];
    if(count($rows)>1500)$rows=array_slice($rows,-1500);
    save_data('events',$rows);
}
function require_admin(): void { if(!is_admin()){flash('برای دسترسی به پنل ابتدا وارد شوید.','error');redirect('?page=admin-login');} }
function upload_image(string $field): string {
    global $UPLOADS;
    if(empty($_FILES[$field])||($_FILES[$field]['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return '';
    $f=$_FILES[$field];
    if(($f['error']??UPLOAD_ERR_OK)!==UPLOAD_ERR_OK)throw new RuntimeException('آپلود تصویر با خطا مواجه شد.');
    if(($f['size']??0)>4*1024*1024)throw new RuntimeException('حجم تصویر باید کمتر از ۴ مگابایت باشد.');
    $info=@getimagesize($f['tmp_name']);
    if(!$info||!in_array($info['mime']??'', ['image/jpeg','image/png','image/webp','image/gif'],true))throw new RuntimeException('فقط تصویر JPG، PNG، WebP یا GIF پذیرفته می‌شود.');
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'][$info['mime']];
    $name=bin2hex(random_bytes(16)).'.'.$ext;
    if(!move_uploaded_file($f['tmp_name'],$UPLOADS.'/'.$name))throw new RuntimeException('ذخیره تصویر ممکن نیست.');
    return 'uploads/'.$name;
}
function image_url(string $path): string { return $path!=='' ? $path : 'https://images.unsplash.com/photo-1607513746994-51f730a44832?auto=format&fit=crop&w=900&q=80'; }
function safe_redirect_target(): string { return '?page=admin'; }
function post_text(string $key, string $default=''): string { $v=$_POST[$key]??$default; return is_string($v)?trim($v):$default; }
function u_lower(string $v): string { return function_exists('mb_strtolower') ? mb_strtolower($v,'UTF-8') : strtolower($v); }
function u_substr(string $v,int $start,?int $length=null): string { return function_exists('mb_substr') ? mb_substr($v,$start,$length,'UTF-8') : substr($v,$start,$length); }
function u_stripos(string $haystack,string $needle): int|false { return function_exists('mb_stripos') ? mb_stripos($haystack,$needle,0,'UTF-8') : stripos($haystack,$needle); }

foreach ($FILES as $key=>$file) if(!is_file($file)) @file_put_contents($file, json_encode([],JSON_UNESCAPED_UNICODE));
if (!is_file($FILES['settings'])) save_settings($DEFAULT_SETTINGS);

$users=all_data('users');
$hasDefaultAdmin=false;
foreach($users as $u) if(u_lower((string)($u['username']??''))==='admin' && ($u['role']??'')==='admin') {$hasDefaultAdmin=true;break;}
if (!$hasDefaultAdmin) {
    // Requested default administrator; keep existing users and store only a secure password hash.
    $bootstrapAdmin=['id'=>uid('usr_'),'username'=>'Admin','password_hash'=>password_hash('Opal1856',PASSWORD_DEFAULT),'role'=>'admin','created_at'=>date('c')];
    array_unshift($users,$bootstrapAdmin); save_data('users',$users);
}
$page=(string)($_GET['page']??'home');
// Privacy-friendly visit analytics: count page views and distinct PHP sessions per day; do not store IP addresses.
if (!in_array($page, ['admin','admin-login','admin-products','admin-product-edit','admin-categories','admin-orders','admin-settings','robots','sitemap','payment-callback','payment-webhook'], true)) {
    $visitData=all_data('visits');
    $day=date('Y-m-d');
    if (!isset($visitData['days']) || !is_array($visitData['days'])) $visitData=['days'=>[],'total_views'=>0];
    if (!isset($visitData['days'][$day]) || !is_array($visitData['days'][$day])) $visitData['days'][$day]=['views'=>0,'unique'=>[]];
    $visitData['days'][$day]['views']=(int)($visitData['days'][$day]['views']??0)+1;
    $sessionKey=hash('sha256',session_id().'|'.$day);
    $visitData['days'][$day]['unique'][$sessionKey]=true;
    $visitData['total_views']=(int)($visitData['total_views']??0)+1;
    save_data('visits',$visitData);
}
$action=(string)($_POST['action']??$_GET['action']??'');
$err='';
if ($page==='payment-webhook') {
    header('Content-Type: application/json; charset=utf-8');
    if (($_SERVER['REQUEST_METHOD']??'GET')!=='POST') { http_response_code(405); echo '{"ok":false}'; exit; }
    $webhookSettings=settings();$webhookSecret=(string)($webhookSettings['rialit_webhook_secret']??'');$webhookKey=(string)($_GET['key']??'');
    if($webhookSecret===''||$webhookKey===''||!hash_equals($webhookSecret,$webhookKey)){http_response_code(403);echo '{"ok":false}';exit;}
    try { rialit_handle_webhook(); http_response_code(200); echo '{"ok":true}'; }
    catch (Throwable $webhookError) {
        $code=(int)$webhookError->getCode(); if($code<400||$code>599)$code=500;
        http_response_code($code); log_event('payment_webhook_error',['code'=>$code,'reason'=>substr($webhookError->getMessage(),0,120)]); echo '{"ok":false}';
    }
    exit;
}
if ($page==='payment-callback' && ($_SERVER['REQUEST_METHOD']??'GET')==='GET') {
    $safeOrderId='';
    try {
        $apiKey=rialit_api_key_value(settings());
        if($apiKey==='')throw new RuntimeException('کلید API ریالیت در تنظیمات مدیریت ثبت نشده است.');
        $token=(string)($_GET['token']??$_GET['payment_token']??'');
        $externalOrder=(string)($_GET['order_id']??'');
        $orders=all_data('orders');$idx=null;
        if($token!=='')$idx=rialit_find_order_index_by_token($orders,$token);
        if($idx===null&&$externalOrder!=='')$idx=rialit_find_order_index_by_external_id($orders,$externalOrder);
        if($idx===null)throw new RuntimeException('سفارش مرتبط با بازگشت Rialit پیدا نشد.');
        $order=$orders[$idx];$safeOrderId=(string)$order['id'];
        if($token===''&& !empty($order['rialit_token']))$token=(string)$order['rialit_token'];
        if($token===''||!rialit_order_has_token($order,$token))throw new RuntimeException('توکن پرداخت با سفارش مطابقت ندارد.');
        $checked=rialit_fetch_payment_status($token,$apiKey);$data=rialit_response_data($checked['data']??[]);
        $status=rialit_payment_status($data);
        if($status==='paid'){
            rialit_assert_paid_data($data,$order,$token);
            rialit_apply_paid_order((string)$order['id'],$token,$data);
            flash('پرداخت از طریق استعلام امن Rialit تأیید شد.');
        } elseif(in_array($status,['failed','cancelled','expired'],true)) {
            rialit_mark_order_failed((string)$order['id'],$token,$status,$data);
            flash('پرداخت در Rialit ناموفق، لغو یا منقضی شده است. در صورت نیاز می‌توانید دوباره تلاش کنید.','error');
        } else {
            flash('پرداخت هنوز نهایی نشده است. پس از تأیید Rialit، وضعیت سفارش به‌روزرسانی می‌شود.','error');
        }
    } catch (Throwable $callbackError) {
        log_event('payment_callback_error',['reason'=>substr($callbackError->getMessage(),0,120)]);
        flash('وضعیت پرداخت هنوز قابل تأیید نیست. اگر مبلغ کسر شده، دوباره پرداخت نکنید تا وضعیت سفارش بررسی شود.','error');
    }
    if($safeOrderId!=='')redirect('?page=order&id='.rawurlencode($safeOrderId));
    redirect('?page=home');
}
try {
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        check_csrf();
        if ($action==='register_user') {
            $username=post_text('username'); $password=(string)($_POST['password']??''); $confirm=(string)($_POST['confirm_password']??'');
            if(!preg_match('/^[A-Za-z0-9_.-]{3,32}$/',$username))throw new RuntimeException('نام کاربری باید ۳ تا ۳۲ نویسه انگلیسی، عدد، نقطه، خط تیره یا زیرخط باشد.');
            if(strlen($password)<8||strlen($password)>200)throw new RuntimeException('رمز عبور باید حداقل ۸ کاراکتر باشد.');
            if(!hash_equals($password,$confirm))throw new RuntimeException('تکرار رمز عبور یکسان نیست.');
            $users=all_data('users'); foreach($users as $u)if(u_lower((string)($u['username']??''))===u_lower($username))throw new RuntimeException('این نام کاربری قبلاً ثبت شده است.');
            $user=['id'=>uid('usr_'),'username'=>$username,'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'role'=>'customer','created_at'=>date('c')];
            $users[]=$user; save_data('users',$users); session_regenerate_id(true); $_SESSION['user_id']=$user['id']; $_SESSION['role']='customer';
            log_event('customer_registered',['username'=>$username]); flash('حساب کاربری با موفقیت ساخته شد.'); redirect('?page=account');
        }
        if ($action==='user_login') {
            if(!empty($_SESSION['user_login_lock_until'])&&time()<(int)$_SESSION['user_login_lock_until'])throw new RuntimeException('تلاش‌های ورود زیاد بوده؛ چند دقیقه دیگر دوباره امتحان کنید.');
            $username=post_text('username'); $password=(string)($_POST['password']??''); $found=null;
            foreach(all_data('users') as $u)if(u_lower((string)($u['username']??''))===u_lower($username)&&($u['role']??'')==='customer'){$found=$u;break;}
            if(!$found||!password_verify($password,(string)($found['password_hash']??''))){
                $_SESSION['user_login_attempts']=(int)($_SESSION['user_login_attempts']??0)+1;
                if($_SESSION['user_login_attempts']>=6){$_SESSION['user_login_lock_until']=time()+300;$_SESSION['user_login_attempts']=0;}
                log_event('customer_login_failed',['username'=>substr($username,0,32)]);throw new RuntimeException('نام کاربری یا رمز عبور صحیح نیست.');
            }
            session_regenerate_id(true); $_SESSION['user_id']=$found['id']; $_SESSION['role']='customer'; $_SESSION['user_login_attempts']=0;
            log_event('customer_login_success',['username'=>$username]); flash('با موفقیت وارد حساب شدی.'); redirect('?page=account');
        }
        if ($action==='user_logout') { if(!is_customer())throw new RuntimeException('ابتدا وارد حساب کاربری شوید.'); $_SESSION=[]; session_regenerate_id(true); flash('از حساب کاربری خارج شدی.'); redirect('?page=home'); }
        if ($action==='admin_login') {
            if(!empty($_SESSION['login_lock_until'])&&time()<(int)$_SESSION['login_lock_until'])throw new RuntimeException('تلاش‌های ورود زیاد بوده؛ چند دقیقه دیگر دوباره امتحان کنید.');
            $username=post_text('username'); $password=(string)($_POST['password']??''); $found=null;
            foreach(all_data('users') as $u)if(hash_equals((string)($u['username']??''),$username)){$found=$u;break;}
            if(!$found||($found['role']??'')!=='admin'||!password_verify($password,(string)($found['password_hash']??''))){
                $_SESSION['login_attempts']=(int)($_SESSION['login_attempts']??0)+1;
                if($_SESSION['login_attempts']>=6){$_SESSION['login_lock_until']=time()+300;$_SESSION['login_attempts']=0;}
                log_event('login_failed',['username'=>substr($username,0,32)]);throw new RuntimeException('نام کاربری یا رمز عبور صحیح نیست.');
            }
            session_regenerate_id(true); $_SESSION['user_id']=$found['id']; $_SESSION['role']=$found['role']; $_SESSION['login_attempts']=0;
            log_event('login_success',['username'=>$username]); redirect('?page=admin');
        }
        if ($action==='logout') { require_admin(); $_SESSION=[]; session_regenerate_id(true); flash('با موفقیت خارج شدید.'); redirect('?page=home'); }
        if (str_starts_with($action,'admin_')) require_admin();

        if ($action==='save_product') {
            $id=post_text('id'); $products=all_data('products'); $idx=null;
            foreach($products as $i=>$p)if(($p['id']??'')===$id&&$id!=='')$idx=$i;
            $name=post_text('name'); if($name==='')throw new RuntimeException('نام محصول الزامی است.');
            $price=(int)($_POST['price']??0); $sale=(int)($_POST['sale_price']??0); if($price<0||$sale<0||($sale>0&&$sale>=$price))throw new RuntimeException('قیمت یا قیمت تخفیف معتبر نیست.');
            $delivery=post_text('delivery_type','manual'); if(!in_array($delivery,['manual','codes','file'],true))$delivery='manual';
            $image=$idx!==null?(string)($products[$idx]['image']??''):''; $uploaded=upload_image('image'); if($uploaded!=='')$image=$uploaded;
            $codes=[];
            if($idx!==null)$codes=$products[$idx]['codes']??[];
            if($delivery==='codes'&&post_text('codes')!==''){
                $codes=[]; foreach(preg_split('/\r\n|\r|\n/',post_text('codes')) as $line){$line=trim($line);if($line!=='')$codes[]=['id'=>uid('code_'),'value'=>$line,'used'=>false,'reserved'=>''];}
            }
            $slug=slugify(post_text('slug')?:$name);
            foreach($products as $j=>$other)if(($other['slug']??'')===$slug&&$j!==$idx)$slug.='-'.substr(uid(),0,4);
            $item=['id'=>$id!==''?$id:uid('prd_'),'name'=>$name,'slug'=>$slug,'description'=>post_text('description'),'details'=>post_text('details'),'category'=>post_text('category'),'platform'=>post_text('platform','Java / Bedrock'),'price'=>$price,'sale_price'=>$sale,'stock'=>(int)($_POST['stock']??0),'delivery_type'=>$delivery,'codes'=>$codes,'image'=>$image,'status'=>post_text('status','draft')==='published'?'published':'draft','seo_title'=>post_text('seo_title')?:$name,'seo_description'=>post_text('seo_description')?:u_substr(strip_tags(post_text('description')),0,155),'created_at'=>$idx!==null?($products[$idx]['created_at']??date('c')):date('c'),'updated_at'=>date('c')];
            if($idx!==null)$products[$idx]=$item;else array_unshift($products,$item);
            save_data('products',$products); log_event('product_saved',['id'=>$item['id']]); flash('محصول ذخیره شد.'); redirect('?page=admin-products');
        }
        if ($action==='delete_product') {
            $id=post_text('id'); $products=array_values(array_filter(all_data('products'),fn($p)=>($p['id']??'')!==$id)); save_data('products',$products); log_event('product_deleted',['id'=>$id]); flash('محصول حذف شد.'); redirect('?page=admin-products');
        }
        if ($action==='save_category') {
            $cats=all_data('categories'); $id=post_text('id'); $name=post_text('name'); if($name==='')throw new RuntimeException('نام دسته الزامی است.');
            $slug=slugify(post_text('slug')?:$name); foreach($cats as $c)if(($c['slug']??'')===$slug&&($c['id']??'')!==$id)$slug.='-'.substr(uid(),0,4);
            $row=['id'=>$id?:uid('cat_'),'name'=>$name,'slug'=>$slug,'description'=>post_text('description')];
            $found=false;foreach($cats as $i=>$c)if(($c['id']??'')===$id&&$id!==''){$cats[$i]=$row;$found=true;}
            if(!$found)$cats[]=$row;save_data('categories',$cats);flash('دسته‌بندی ذخیره شد.');redirect('?page=admin-categories');
        }
        if ($action==='delete_category') {
            $id=post_text('id'); save_data('categories',array_values(array_filter(all_data('categories'),fn($c)=>($c['id']??'')!==$id))); flash('دسته‌بندی حذف شد.');redirect('?page=admin-categories');
        }
        if ($action==='save_settings') {
            require_admin();
            $s=settings(); foreach(['site_name','tagline','description','about','contact_email','contact_phone','telegram','instagram','seo_title','seo_description','shipping_note'] as $k)$s[$k]=post_text($k);
            $s['payment_enabled']=post_text('payment_enabled')==='1'?'1':'0';
            $s['payment_explicitly_disabled']=$s['payment_enabled']==='1'?'0':'1';
            $s['payment_mode']='normal';
            $cb=trim(post_text('payment_callback_url')); if($cb!==''&&(!filter_var($cb,FILTER_VALIDATE_URL)||strtolower((string)parse_url($cb,PHP_URL_SCHEME))!=='https'))throw new RuntimeException('آدرس بازگشت Rialit باید یک URL معتبر HTTPS باشد.'); $s['payment_callback_url']=$cb;
            $submittedRialitKey=rialit_normalize_api_key(post_text('rialit_api_key'));
            if($submittedRialitKey!==''){
                $s['rialit_api_key']=$submittedRialitKey;
                // Entering an API key is an explicit setup action; enable the gateway automatically.
                $s['payment_enabled']='1';
                $s['payment_explicitly_disabled']='0';
            }
            if(rialit_api_key_value($s)!=='' && trim((string)($s['rialit_webhook_secret']??''))==='')$s['rialit_webhook_secret']=bin2hex(random_bytes(32));
            foreach (['logo_path'=>'logo_upload','favicon_path'=>'favicon_upload'] as $settingKey=>$fieldName) {
                if (!empty($_POST['remove_'.$settingKey])) $s[$settingKey]='';
                $uploaded=upload_image($fieldName);
                if ($uploaded!=='') $s[$settingKey]=$uploaded;
            }
            save_settings($s);
            // Verify persisted credentials immediately so a failed/incorrect save never looks successful.
            $savedSettings=settings();
            if($submittedRialitKey!=='' && !hash_equals($submittedRialitKey,rialit_api_key_value($savedSettings))) {
                throw new RuntimeException('ذخیره کلید API Rialit تأیید نشد. مجوز نوشتن پوشه data و فایل data/settings.json را بررسی کنید.');
            }
            flash($submittedRialitKey!==''?'تنظیمات ذخیره شد و کلید API Rialit روی سرور ثبت شد.':'تنظیمات ذخیره شد.');redirect('?page=admin-settings');
        }
        if ($action==='change_password') {
            require_admin();
            $users=all_data('users');$new=(string)($_POST['new_password']??'');$confirm=(string)($_POST['confirm_password']??'');
            if(strlen($new)<12||!hash_equals($new,$confirm))throw new RuntimeException('رمز جدید باید حداقل ۱۲ کاراکتر باشد و با تکرار آن یکسان باشد.');
            foreach($users as &$u)if(($u['id']??'')===($_SESSION['user_id']??''))$u['password_hash']=password_hash($new,PASSWORD_DEFAULT);unset($u);save_data('users',$users);flash('رمز عبور تغییر کرد.');redirect('?page=admin-settings');
        }
        if ($action==='add_cart') {
            $id=post_text('id');$qty=max(1,min(10,(int)($_POST['qty']??1)));$p=product_by_id($id);
            if(!$p||($p['status']??'')!=='published')throw new RuntimeException('محصول در دسترس نیست.');
            if(stock_count($p)<$qty)throw new RuntimeException('موجودی کافی نیست.');
            $_SESSION['cart']=$_SESSION['cart']??[];$_SESSION['cart'][$id]=min(10,(int)($_SESSION['cart'][$id]??0)+$qty);
            flash('محصول به سبد خرید اضافه شد.');redirect('?page=cart');
        }
        if ($action==='update_cart') {
            $cart=$_SESSION['cart']??[];foreach($cart as $id=>$q){$n=max(0,min(10,(int)($_POST['qty'][$id]??$q)));if($n===0)unset($cart[$id]);else$cart[$id]=$n;}$_SESSION['cart']=$cart;flash('سبد خرید به‌روزرسانی شد.');redirect('?page=cart');
        }
        if ($action==='checkout') {
            $cart=$_SESSION['cart']??[];if(!$cart)throw new RuntimeException('سبد خرید خالی است.');
            $name=post_text('customer_name');$email=filter_var(post_text('email'),FILTER_VALIDATE_EMAIL);$phone=post_text('phone');
            if($name===''||!$email||$phone==='')throw new RuntimeException('نام، ایمیل معتبر و شماره تماس را وارد کنید.');
            $products=all_data('products');$lines=[];$total=0;
            foreach($cart as $id=>$qty){$p=null;foreach($products as $x)if(($x['id']??'')===$id)$p=$x;if(!$p||($p['status']??'')!=='published')throw new RuntimeException('یکی از محصولات سبد خرید دیگر موجود نیست.');
                $qty=max(1,(int)$qty);if(stock_count($p)<$qty)throw new RuntimeException('موجودی محصول «'.$p['name'].'» کافی نیست.');
                $unit=product_price($p);$lines[]=['product_id'=>$id,'name'=>$p['name'],'slug'=>$p['slug'],'qty'=>$qty,'unit_price'=>$unit,'line_total'=>$unit*$qty,'delivery_type'=>$p['delivery_type']??'manual'];$total+=$unit*$qty;
            }
            $discountCode=strtoupper(post_text('discount_code'));$discountAmount=0;
            if($discountCode!==''){foreach(all_data('discounts') as $d)if(strtoupper((string)($d['code']??''))===$discountCode&&!empty($d['active'])&&strtotime((string)($d['expires_at']??'2999-01-01'))>=time()){$discountAmount=($d['type']??'percent')==='fixed'?min($total,(int)$d['value']):min($total,(int)floor($total*min(100,(int)$d['value'])/100));break;}}
            $order=['id'=>uid('ord_'),'number'=>strtoupper(substr(bin2hex(random_bytes(5)),0,10)),'customer'=>['name'=>$name,'email'=>$email,'phone'=>$phone],'items'=>$lines,'subtotal'=>$total,'discount'=>$discountAmount,'total'=>max(0,$total-$discountAmount),'status'=>'pending','payment_status'=>'pending','payment_provider'=>'rialit','trace_code'=>'','created_at'=>date('c'),'delivered'=>false,'delivery'=>[]];
            $orders=all_data('orders');array_unshift($orders,$order);save_data('orders',$orders);$_SESSION['last_order']=$order['id'];$_SESSION['cart']=[];
            redirect('?page=order&id='.rawurlencode($order['id']));
        }
        if ($action==='create_payment') {
            $orderId=post_text('order_id');
            $paymentResult=rialit_start_payment($orderId);
            if(!empty($paymentResult['paid']))flash('پرداخت سفارش از طریق Rialit تأیید شد.');
            redirect((string)$paymentResult['url']);
        }
    }
} catch (Throwable $ex) {
    $err=$ex->getMessage();
    if($action==='create_payment') {
        flash($err,'error');
        $failedOrderId=post_text('order_id');
        if($failedOrderId!=='')redirect('?page=order&id='.rawurlencode($failedOrderId));
    }
}

/** Make an authenticated request to Rialit's production API. */
function rialit_api_request(string $method,string $path,array $payload,string $apiKey): array {
    if(!preg_match('~^/(send|payment/[A-Za-z0-9_-]{1,128}|verify/[A-Za-z0-9_-]{1,128})$~',$path))throw new RuntimeException('مسیر API ریالیت معتبر نیست.',500);
    if(!in_array($method,['GET','POST'],true))throw new RuntimeException('روش درخواست API ریالیت معتبر نیست.',500);
    $url='https://api.rialit.io/api/v1'.$path;
    $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if($json===false)throw new RuntimeException('ساخت درخواست Rialit ناموفق بود.',500);
    $headers=['Accept: application/json','Content-Type: application/json','Authorization: Bearer '.$apiKey];
    $body=false;$status=0;$error='';
    if(function_exists('curl_init')){
        $ch=curl_init($url);
        $options=[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CUSTOMREQUEST=>$method,
            CURLOPT_CONNECTTIMEOUT=>10,
            CURLOPT_TIMEOUT=>25,
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_HTTPHEADER=>$headers
        ];
        if($method==='POST')$options[CURLOPT_POSTFIELDS]=$json;
        curl_setopt_array($ch,$options);
        $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$error=curl_error($ch);curl_close($ch);
    } else {
        if(!filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))throw new RuntimeException('برای اتصال به Rialit، cURL یا allow_url_fopen باید در PHP فعال باشد.',503);
        $context=stream_context_create([
            'http'=>['method'=>$method,'header'=>implode("\r\n",$headers),'content'=>$method==='POST'?$json:'','timeout'=>25,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0],
            'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]
        ]);
        $body=@file_get_contents($url,false,$context);$responseHeaders=$http_response_header??[];
        if(isset($responseHeaders[0])&&preg_match('/\s([0-9]{3})\s/',$responseHeaders[0],$m))$status=(int)$m[1];
        if($body===false)$error='ارتباط HTTPS با API برقرار نشد.';
    }
    if($body===false)throw new RuntimeException('ارتباط امن با Rialit برقرار نشد: '.$error,503);
    $decoded=json_decode((string)$body,true);
    if(!is_array($decoded)){
        if($status>=200&&$status<300)throw new RuntimeException('Rialit پاسخ JSON معتبر ارسال نکرد.',502);
        $decoded=['message'=>substr(strip_tags((string)$body),0,300)];
    }
    return ['http_status'=>$status,'data'=>$decoded];
}
function rialit_response_data(array $response): array {
    $out=$response;
    foreach(['data','payment','result'] as $key)if(isset($response[$key])&&is_array($response[$key]))$out=array_merge($out,$response[$key]);
    if(isset($out['data'])&&is_array($out['data']))$out=array_merge($out,$out['data']);
    return $out;
}
function rialit_safe_message(array $response): string {
    $data=rialit_response_data($response['data']??$response);
    $message=(string)($data['message']??$data['detail']??$data['error_description']??$data['error']??'');
    $message=trim(preg_replace('/\s+/u',' ',strip_tags($message))??'');
    return $message!==''?substr($message,0,240):'';
}
function rialit_http_error_message(int $status,array $response): string {
    $detail=rialit_safe_message($response);$extra=$detail!==''?' جزئیات: '.$detail:'';
    if($status===401)return 'Rialit کلید API را نپذیرفت؛ کلید فعال و درست را در پنل مدیریت ثبت کنید.'.$extra;
    if($status===403)return 'Rialit درخواست را با HTTP 403 رد کرد؛ دسترسی API، وضعیت حساب و هرگونه محدودیت IP را در پنل Rialit بررسی کنید.'.$extra;
    if($status===429)return 'تعداد درخواست‌های Rialit بیش از حد مجاز است؛ کمی بعد دوباره تلاش کنید.'.$extra;
    if($status===400||$status===422)return 'Rialit اطلاعات درخواست را نپذیرفت؛ مبلغ و شناسه‌های ارسالی را بررسی کنید.'.$extra;
    return 'پاسخ API ریالیت موفق نبود (HTTP '.($status?:'نامشخص').').'.$extra;
}
function rialit_payment_status(array $data): string {
    $data=rialit_response_data($data);
    $raw=$data['payment_status']??$data['state']??$data['status']??'';
    if(!is_scalar($raw))return 'unknown';
    $status=strtolower(trim((string)$raw));
    if(in_array($status,['3','paid','success','successful','completed','complete','confirmed'],true))return 'paid';
    if(in_array($status,['4','failed','failure','cancelled','canceled','expired','rejected'],true)){
        if(in_array($status,['cancelled','canceled'],true))return 'cancelled';
        if($status==='expired')return 'expired';
        return 'failed';
    }
    if(in_array($status,['0','1','2','pending','created','waiting','unpaid','processing','initiated','new'],true))return 'pending';
    return 'unknown';
}
function rialit_payer_id(array $order): int {
    // Rialit expects a positive integer merchant-side payer identifier; derive a stable, non-PII numeric ID from the email.
    $email=strtolower(trim((string)($order['customer']['email']??$order['id']??'opal-customer')));
    return max(1,(int)hexdec(substr(hash('sha256',$email),0,12)));
}
function rialit_find_order_index(array $orders,string $orderId): ?int {
    foreach($orders as $i=>$row)if(is_array($row)&&($row['id']??'')===$orderId)return $i;
    return null;
}
function rialit_find_order_index_by_external_id(array $orders,string $externalId): ?int {
    foreach($orders as $i=>$row)if(is_array($row)&&(($row['rialit_order_id']??'')===$externalId||($row['number']??'')===$externalId))return $i;
    return null;
}
function rialit_order_has_token(array $order,string $token): bool {
    if($token==='' )return false;
    if((string)($order['rialit_token']??'')===$token)return true;
    foreach(($order['rialit_payments']??[]) as $attempt)if(is_array($attempt)&&(string)($attempt['token']??'')===$token)return true;
    return false;
}
function rialit_find_order_index_by_token(array $orders,string $token): ?int {
    foreach($orders as $i=>$order)if(is_array($order)&&rialit_order_has_token($order,$token))return $i;
    return null;
}
function rialit_payment_attempt_index(array $order,string $token): ?int {
    foreach(($order['rialit_payments']??[]) as $i=>$attempt)if(is_array($attempt)&&(string)($attempt['token']??'')===$token)return (int)$i;
    return null;
}
function rialit_mark_attempt_status(array $order,string $token,string $status,array $gatewayData=[]): array {
    $attempts=is_array($order['rialit_payments']??null)?$order['rialit_payments']:[];
    foreach($attempts as &$attempt){
        if(is_array($attempt)&&(string)($attempt['token']??'')===$token){
            $attempt['status']=$status;$attempt['updated_at']=date('c');
            $ref=$gatewayData['reference_id']??$gatewayData['transaction_id']??$gatewayData['provider_order_id']??null;
            if($ref!==null)$attempt['reference_id']=(string)$ref;
        }
    }unset($attempt);
    $order['rialit_payments']=$attempts;
    if((string)($order['rialit_token']??'')===$token)$order['rialit_payment_status']=$status;
    return $order;
}
function rialit_fetch_payment_status(string $token,string $apiKey): array {
    if(!preg_match('/^[A-Za-z0-9_-]{1,128}$/',$token))throw new RuntimeException('توکن پرداخت Rialit معتبر نیست.',422);
    $res=rialit_api_request('GET','/payment/'.rawurlencode($token),[],$apiKey);
    // Some deployments expose a dedicated verify endpoint rather than a read-only payment endpoint.
    // Fall back only when the read endpoint is not available; do not repeatedly consume verify attempts for pending payments.
    if(in_array((int)$res['http_status'],[404,405,501],true))$res=rialit_api_request('POST','/verify/'.rawurlencode($token),[],$apiKey);
    return $res;
}
function rialit_assert_paid_data(array $data,array $order,string $token): void {
    $data=rialit_response_data($data);
    if(rialit_payment_status($data)!=='paid')throw new RuntimeException('Rialit هنوز پرداخت را به‌طور قطعی تأیید نکرده است.',503);
    $remoteToken=(string)($data['token']??$data['payment_token']??'');
    if($remoteToken!==''&&!hash_equals($token,$remoteToken))throw new RuntimeException('توکن تأییدشده Rialit با سفارش مطابقت ندارد.',422);
    $expectedOrder=(string)($order['rialit_order_id']??$order['number']??'');
    if($expectedOrder==='')throw new RuntimeException('شناسه سفارش ثبت‌شده در سایت موجود نیست.',422);
    $remoteOrder=(string)($data['order_id']??$data['merchant_order_id']??'');
    if($remoteOrder!==''&&!hash_equals($expectedOrder,$remoteOrder))throw new RuntimeException('شناسه سفارش در پاسخ Rialit با سفارش مطابقت ندارد.',422);
    $remoteAmount=$data['amount']??$data['amount_toman']??null;
    if($remoteAmount!==null&&(!is_numeric($remoteAmount)||(int)$remoteAmount!==(int)($order['total']??-1)))throw new RuntimeException('مبلغ تأییدشده Rialit با مبلغ سفارش مطابقت ندارد.',422);
    // If the API status response omits order_id/amount, the token-to-order association and requested amount remain stored locally from the authenticated create call. Any returned values above are still strictly compared.
}
function rialit_mark_order_failed(string $orderId,string $token,string $status,array $gatewayData=[]): void {
    global $DATA;
    $lockPath=$DATA.'/rialit-order-'.hash('sha256',$orderId).'.lock';$lock=@fopen($lockPath,'c');
    if(!$lock||!flock($lock,LOCK_EX)){if(is_resource($lock))fclose($lock);throw new RuntimeException('قفل به‌روزرسانی سفارش در دسترس نیست.',503);}
    try {
        $orders=all_data('orders');$idx=rialit_find_order_index($orders,$orderId);if($idx===null)throw new RuntimeException('سفارش مربوط به پرداخت پیدا نشد.',404);
        $order=$orders[$idx];if(($order['payment_provider']??'')!=='rialit'||!rialit_order_has_token($order,$token))throw new RuntimeException('توکن پرداخت متعلق به این سفارش نیست.',422);
        if(($order['payment_status']??'')==='paid')return;
        $order=rialit_mark_attempt_status($order,$token,$status,$gatewayData);$order['payment_status']='failed';$order['status']='payment_failed';$order['rialit_payment_status']=$status;
        $orders[$idx]=$order;save_data('orders',$orders);log_event('payment_failed',['order'=>$orderId,'provider'=>'rialit','status'=>$status]);
    } finally {flock($lock,LOCK_UN);fclose($lock);}
}
function rialit_apply_paid_order(string $orderId,string $token,array $verifiedData): void {
    global $DATA;
    $lockPath=$DATA.'/rialit-order-'.hash('sha256',$orderId).'.lock';$lock=@fopen($lockPath,'c');
    if(!$lock||!flock($lock,LOCK_EX)){if(is_resource($lock))fclose($lock);throw new RuntimeException('قفل تأیید سفارش در دسترس نیست.',503);}
    try {
        $orders=all_data('orders');$idx=rialit_find_order_index($orders,$orderId);if($idx===null)throw new RuntimeException('سفارش مربوط به پرداخت پیدا نشد.',404);
        $order=$orders[$idx];
        if(($order['payment_provider']??'')!=='rialit'||!rialit_order_has_token($order,$token))throw new RuntimeException('توکن پرداخت متعلق به این سفارش نیست.',422);
        rialit_assert_paid_data($verifiedData,$order,$token);
        $attemptIndex=rialit_payment_attempt_index($order,$token);
        $attemptAlreadyPaid=$attemptIndex!==null&&strtolower((string)($order['rialit_payments'][$attemptIndex]['status']??''))==='paid';
        if(($order['payment_status']??'')==='paid'){
            if($attemptAlreadyPaid)return;
            $order=rialit_mark_attempt_status($order,$token,'paid',$verifiedData);
            $dupes=is_array($order['rialit_duplicate_payments']??null)?$order['rialit_duplicate_payments']:[];$known=false;
            foreach($dupes as $dupe)if(is_array($dupe)&&(string)($dupe['token']??'')===$token)$known=true;
            if(!$known){$dupes[]=['token'=>$token,'reference_id'=>(string)($verifiedData['reference_id']??$verifiedData['transaction_id']??''),'received_at'=>date('c')];$order['rialit_duplicate_payments']=$dupes;}
            $orders[$idx]=$order;save_data('orders',$orders);log_event('duplicate_payment_received',['order'=>$orderId,'provider'=>'rialit','token_hash'=>hash('sha256',$token)]);return;
        }
        $order=rialit_mark_attempt_status($order,$token,'paid',$verifiedData);$order['payment_status']='paid';$order['status']='paid';$order['verified_at']=date('c');$order['rialit_payment_status']='paid';
        $order['trace_code']=(string)($verifiedData['reference_id']??$verifiedData['transaction_id']??$verifiedData['provider_order_id']??$order['trace_code']??'');
        $order=deliver_order($order);$orders[$idx]=$order;save_data('orders',$orders);
        log_event('payment_verified',['order'=>$orderId,'provider'=>'rialit']);
    } finally {flock($lock,LOCK_UN);fclose($lock);}
}
function rialit_start_payment(string $orderId): array {
    global $DATA;
    if($orderId==='')throw new RuntimeException('شناسه سفارش خالی است.');
    $lockPath=$DATA.'/rialit-create-'.hash('sha256',$orderId).'.lock';$lock=@fopen($lockPath,'c');
    if(!$lock||!flock($lock,LOCK_EX)){if(is_resource($lock))fclose($lock);throw new RuntimeException('قفل ساخت پرداخت در دسترس نیست.',503);}
    try {
        $orders=all_data('orders');$idx=rialit_find_order_index($orders,$orderId);if($idx===null)throw new RuntimeException('سفارش پیدا نشد.',404);
        $order=$orders[$idx];
        if(!is_admin()&&(!isset($_SESSION['last_order'])||!hash_equals((string)$_SESSION['last_order'],$orderId)))throw new RuntimeException('دسترسی به این سفارش مجاز نیست.',403);
        if(($order['payment_status']??'')==='paid')return ['url'=>'?page=order&id='.rawurlencode($orderId),'paid'=>true];
        $s=settings();$apiKey=rialit_api_key_value($s);
        if(($s['payment_enabled']??'0')!=='1'&&($s['payment_explicitly_disabled']??'')==='1')throw new RuntimeException('پرداخت در تنظیمات مدیریت غیرفعال است.');
        if($apiKey==='')throw new RuntimeException('کلید API Rialit را در تنظیمات مدیریت ثبت کنید.');
        $amount=(int)($order['total']??0);if($amount<1)throw new RuntimeException('مبلغ سفارش باید بیشتر از صفر تومان باشد.');

        // Reuse the current checkout while it is still pending; never create a second charge just because a customer refreshed.
        if(($order['payment_status']??'')==='pending'&&($order['payment_provider']??'')==='rialit'&&!empty($order['rialit_token'])&&!empty($order['rialit_payment_url'])){
            $previousToken=(string)$order['rialit_token'];
            try {
                $previous=rialit_fetch_payment_status($previousToken,$apiKey);$http=(int)($previous['http_status']??0);$prevData=rialit_response_data($previous['data']??[]);$prevStatus=rialit_payment_status($prevData);
                if($http>=200&&$http<300&&$prevStatus==='paid'){
                    rialit_assert_paid_data($prevData,$order,$previousToken);rialit_apply_paid_order($orderId,$previousToken,$prevData);
                    return ['url'=>'?page=order&id='.rawurlencode($orderId),'paid'=>true];
                }
                if($http>=200&&$http<300&&in_array($prevStatus,['failed','cancelled','expired'],true)){
                    rialit_mark_order_failed($orderId,$previousToken,$prevStatus,$prevData);
                } else {
                    // Unknown/pending is safer to reuse than to issue a duplicate payment request.
                    return ['url'=>(string)$order['rialit_payment_url'],'paid'=>false];
                }
            } catch(Throwable $statusError) {
                return ['url'=>(string)$order['rialit_payment_url'],'paid'=>false];
            }
        }

        $externalOrder=(string)($order['number']??$orderId);
        $payload=['amount'=>$amount,'order_id'=>$externalOrder,'payer_id'=>rialit_payer_id($order)];
        $res=rialit_api_request('POST','/send',$payload,$apiKey);$http=(int)($res['http_status']??0);$data=rialit_response_data($res['data']??[]);
        if($http<200||$http>=300)throw new RuntimeException(rialit_http_error_message($http,$res),($http>=400&&$http<=599)?$http:502);
        if(strtolower((string)($data['status']??''))==='error'||!empty($data['success'])&&$data['success']===false)throw new RuntimeException('Rialit درخواست پرداخت را نپذیرفت. '.rialit_safe_message($res),502);
        $token=(string)($data['token']??$data['payment_token']??'');
        if($token===''||!preg_match('/^[A-Za-z0-9_-]{1,128}$/',$token))throw new RuntimeException('پاسخ Rialit توکن پرداخت معتبر نداشت؛ پرداخت ایجاد نشده تلقی شد.',502);
        $paymentUrl='https://pay.rialit.io/v1/'.rawurlencode($token);

        // Persist the token before redirecting to checkout.
        $orders=all_data('orders');$idx=rialit_find_order_index($orders,$orderId);if($idx===null)throw new RuntimeException('سفارش پس از ایجاد پرداخت پیدا نشد.',404);
        $order=$orders[$idx];if(($order['payment_status']??'')==='paid')return ['url'=>'?page=order&id='.rawurlencode($orderId),'paid'=>true];
        $attempts=is_array($order['rialit_payments']??null)?$order['rialit_payments']:[];
        $attempts[]=['token'=>$token,'payment_url'=>$paymentUrl,'status'=>'pending','amount'=>$amount,'order_id'=>$externalOrder,'created_at'=>date('c')];
        $order['rialit_payments']=$attempts;$order['payment_provider']='rialit';$order['rialit_token']=$token;$order['rialit_payment_url']=$paymentUrl;$order['rialit_order_id']=$externalOrder;
        $order['payment_started_at']=date('c');$order['payment_status']='pending';$order['status']='pending';$order['rialit_payment_status']='pending';
        $orders[$idx]=$order;save_data('orders',$orders);log_event('payment_started',['order'=>$orderId,'provider'=>'rialit']);
        return ['url'=>$paymentUrl,'paid'=>false];
    } finally {flock($lock,LOCK_UN);fclose($lock);}
}
function rialit_handle_webhook(): void {
    $apiKey=rialit_api_key_value(settings());if($apiKey==='')throw new RuntimeException('کلید API Rialit در تنظیمات مدیریت ثبت نشده است.',503);
    $raw=file_get_contents('php://input');if(!is_string($raw)||$raw==='')throw new RuntimeException('بدنه وب‌هوک خالی است.',400);
    $eventData=json_decode($raw,true);if(!is_array($eventData))throw new RuntimeException('JSON وب‌هوک Rialit معتبر نیست.',400);
    $event=(string)($eventData['event']??$eventData['type']??$eventData['event_name']??$_SERVER['HTTP_X_RIALIT_EVENT']??'');
    $event=strtolower(trim($event));
    if($event!==''&&!in_array($event,['payment.paid','payment.expired','payment.cancelled','payment.canceled','paid','expired','cancelled','canceled'],true))return;
    $inner=$eventData;
    foreach(['data','payment','payload','object'] as $k)if(isset($eventData[$k])&&is_array($eventData[$k]))$inner=array_merge($inner,$eventData[$k]);
    $token=(string)($inner['token']??$inner['payment_token']??$eventData['token']??$eventData['payment_token']??'');
    $externalOrder=(string)($eventData['order_id']??$inner['order_id']??$inner['merchant_order_id']??'');
    $orders=all_data('orders');$idx=$token!==''?rialit_find_order_index_by_token($orders,$token):null;
    if($idx===null&&$externalOrder!=='')$idx=rialit_find_order_index_by_external_id($orders,$externalOrder);
    if($idx===null)throw new RuntimeException('سفارش مرتبط با وب‌هوک Rialit پیدا نشد.',404);
    $order=$orders[$idx];if($token===''&&!empty($order['rialit_token']))$token=(string)$order['rialit_token'];
    if($token===''||!rialit_order_has_token($order,$token))throw new RuntimeException('توکن وب‌هوک با سفارش مطابقت ندارد.',422);
    // Never trust the event body alone: always confirm the payment directly with Rialit's authenticated API.
    $checked=rialit_fetch_payment_status($token,$apiKey);$http=(int)($checked['http_status']??0);$data=rialit_response_data($checked['data']??[]);
    if($http===409){throw new RuntimeException('Rialit هنوز پرداخت را نهایی نکرده است؛ وب‌هوک باید دوباره ارسال شود.',503);}
    if(in_array($http,[404,405,501],true) && in_array($event,['payment.paid','paid','payment.expired','expired','payment.cancelled','payment.canceled','cancelled','canceled'],true)){
        // If Rialit's deployment does not expose a status endpoint, accept events only at the unguessable URL generated in merchant settings.
        if($externalOrder!=='' && !hash_equals((string)($order['rialit_order_id']??$order['number']??''),$externalOrder))throw new RuntimeException('شناسه سفارش در وب‌هوک Rialit مطابقت ندارد.',422);
        $isPaid=in_array($event,['payment.paid','paid'],true);
        if(!$isPaid){rialit_mark_order_failed((string)$order['id'],$token,str_contains($event,'expired')||$event==='expired'?'expired':'cancelled',$inner);return;}
        $eventAmount=$inner['amount']??$inner['amount_toman']??null;
        if($eventAmount!==null&&(!is_numeric($eventAmount)||(int)$eventAmount!==(int)($order['total']??-1)))throw new RuntimeException('مبلغ وب‌هوک Rialit با مبلغ سفارش مطابقت ندارد.',422);
        $trustedEvent=['status'=>'paid','token'=>$token,'order_id'=>(string)($order['rialit_order_id']??$order['number']??''),'amount'=>(int)($order['total']??0),'reference_id'=>(string)($inner['reference_id']??$inner['transaction_id']??'')];
        rialit_assert_paid_data($trustedEvent,$order,$token);rialit_apply_paid_order((string)$order['id'],$token,$trustedEvent);return;
    }
    if($http<200||$http>=300)throw new RuntimeException(rialit_http_error_message($http,$checked),503);
    $status=rialit_payment_status($data);
    if($status==='paid'){
        rialit_assert_paid_data($data,$order,$token);rialit_apply_paid_order((string)$order['id'],$token,$data);return;
    }
    if(in_array($status,['failed','cancelled','expired'],true)){
        rialit_mark_order_failed((string)$order['id'],$token,$status,$data);return;
    }
    if(in_array($event,['payment.paid','paid'],true))throw new RuntimeException('رویداد paid دریافت شد اما API Rialit هنوز پرداخت را تأیید نکرده است.',503);
    // A non-final webhook is acknowledged only after authoritative status lookup; no order is marked paid from the webhook payload.
}
function deliver_order(array $order): array {
    if(!empty($order['delivered']))return $order;
    $products=all_data('products');$delivery=[];
    foreach(($order['items']??[]) as $line){
        $qty=max(1,(int)($line['qty']??1));$idx=null;
        foreach($products as $i=>$p)if(($p['id']??'')===($line['product_id']??''))$idx=$i;
        if($idx===null){$delivery[]=['product'=>$line['name'],'type'=>'manual','message'=>'برای تحویل این محصول با پشتیبانی تماس بگیرید.'];continue;}
        $p=&$products[$idx];$type=$p['delivery_type']??'manual';
        if($type==='codes'){
            $codes=$p['codes']??[];$given=[];
            foreach($codes as &$c){if(count($given)>=$qty)break;if(empty($c['used'])&&empty($c['reserved'])){$c['used']=true;$c['used_at']=date('c');$c['used_order']=$order['id'];$given[]=(string)$c['value'];}}unset($c);
            $p['codes']=$codes;$delivery[]=['product'=>$line['name'],'type'=>'codes','values'=>$given,'message'=>count($given)===$qty?'کد دیجیتال شما آماده است.':'موجودی کد کافی نبود؛ تحویل با بررسی مدیر تکمیل می‌شود.'];
        }elseif($type==='file'){$delivery[]=['product'=>$line['name'],'type'=>'file','file'=>$p['download_file']??'','message'=>'فایل محصول از بخش جزئیات سفارش قابل دریافت است.'];}
        else {$delivery[]=['product'=>$line['name'],'type'=>'manual','message'=>'سفارش برای تحویل دستی ثبت شد.'];}
        if($type!=='codes')$p['stock']=max(0,(int)($p['stock']??0)-$qty);
        unset($p);
    }
    save_data('products',$products);$order['delivery']=$delivery;$order['delivered']=true;$order['delivered_at']=date('c');$order['status']='delivered';return $order;
}

$settings=settings();
$flash=$_SESSION['flash']??null;unset($_SESSION['flash']);
$products=public_products();$categories=all_data('categories');$cart=$_SESSION['cart']??[];
$cartCount=array_sum($cart);
$search=trim((string)($_GET['q']??''));$categoryFilter=(string)($_GET['category']??'');
$visibleProducts=array_values(array_filter($products,function($p)use($search,$categoryFilter){
    $match=$search===''||u_stripos((string)($p['name']??''),$search)!==false||u_stripos((string)($p['description']??''),$search)!==false;
    $cat=$categoryFilter===''||($p['category']??'')===$categoryFilter;return $match&&$cat;
}));
usort($visibleProducts,function($a,$b){$sort=(string)($_GET['sort']??'new');if($sort==='price_asc')return product_price($a)<=>product_price($b);if($sort==='price_desc')return product_price($b)<=>product_price($a);return strcmp((string)($b['created_at']??''),(string)($a['created_at']??''));});
$productId=(string)($_GET['id']??'');$selectedProduct=null;if($page==='product'){foreach($products as $p)if(($p['id']??'')===$productId||($p['slug']??'')===$productId)$selectedProduct=$p;}
$order=null;if($page==='order'){foreach(all_data('orders') as $o)if(($o['id']??'')===$productId)$order=$o;}
$editing=null;if(is_admin()&&$page==='admin-product-edit'&&$productId!=='')$editing=product_by_id($productId);
if ($page==='account' && !is_customer()) redirect('?page=user-login');
if (in_array($page,['user-login','register'],true) && is_customer()) redirect('?page=account');
function render_header(string $title=''): void {
    global $settings,$cartCount,$page;
    $siteName=trim((string)($settings['site_name']??'Opal')) ?: 'Opal';
    $tagline=trim((string)($settings['tagline']??''));
    $full = 'Opal | فروشگاه ماینکرافت';
    $logo=trim((string)($settings['logo_path']??''));
    $favicon=trim((string)($settings['favicon_path']??''));
    $brandMark=$logo!=='' ? '<img class="brand-logo" src="'.h($logo).'" alt="'.h($siteName).'">' : '<span class="brand-mark">'.h(u_substr($siteName,0,1)).'</span>';
    $faviconHtml=$favicon!=='' ? '<link rel="icon" href="'.h($favicon).'">' : '';
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#f4fbff"><meta name="description" content="'.h($settings['seo_description']).'"><title>'.h($full).'</title>'.$faviconHtml.'<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Estedad:wght@400;500;600;700;800&display=swap" rel="stylesheet"><style>';

    echo CSS;
    echo "\n/* Opal refinement layer */\n.visit-chart{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:12px;align-items:end;min-height:190px;padding:16px 4px 4px}.visit-day{text-align:center;display:flex;flex-direction:column;align-items:center;gap:5px;min-width:0}.visit-bars{height:105px;width:min(34px,80%);display:flex;align-items:end;justify-content:center;background:#eaf8ff;border-radius:12px;overflow:hidden}.visit-bar{display:block;width:100%;min-height:4px;border-radius:10px;background:linear-gradient(180deg,#72dcff,#168bd4);box-shadow:0 3px 12px #168bd42b}.visit-day b{font-size:13px}.visit-day small,.visit-day em{font-size:10px;color:var(--muted);font-style:normal}.admin-main .stat-grid{margin-bottom:16px}.admin-main .stat{background:linear-gradient(145deg,#ffffffd9,#effaffb8);border:1px solid #d9eff9;box-shadow:0 10px 28px #3889b010}.admin-side a{transition:background .18s,color .18s,transform .18s}.admin-side a:hover{transform:translateX(-2px)}.btn,.admin-link,.icon-btn,.category-tile,.product-card,.panel,.stat{transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}.panel{border-color:#dceef6}.data-table th{font-family:Estedad,Vazirmatn,Tahoma,sans-serif}.brand-logo{width:44px;height:44px;object-fit:contain;border-radius:13px;display:block}.brand-settings{padding:14px;border:1px solid #dceef6;border-radius:16px;background:#ffffff80;margin:6px 0}.brand-preview{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:10px;font-size:12px;color:var(--muted)}.brand-preview img{width:56px;height:56px;object-fit:contain;border:1px solid var(--line);border-radius:12px;background:#fff;padding:4px}.brand-preview img.favicon-preview{width:36px;height:36px}.brand-preview label{display:flex;align-items:center;gap:6px}.footer-brand .brand-logo{width:40px;height:40px}.topbar{z-index:100}.desktop-nav a{transition:background .2s,color .2s}.desktop-nav a:hover,.desktop-nav a.nav-active{background:#e5f7ff;color:#137db5;border-radius:12px}.hero-copy,.hero-art,.product-card,.category-tile,.trust-item,.promo{animation:opal-enter .55s both}.product-card:hover{transform:translateY(-5px);box-shadow:0 22px 48px #70b9d51c}.btn{transition:transform .18s,box-shadow .18s,background .18s}.btn:hover{transform:translateY(-1px);box-shadow:0 9px 22px #3ca8d51f}.section-head{align-items:end}.footer{margin-top:36px}.admin-link-secondary{background:#fff;color:var(--ink);border:1px solid var(--line);box-shadow:none}.account-link{white-space:nowrap}.account-card{max-width:720px;margin:24px auto;padding:26px;border-radius:26px}.account-hero{display:flex;align-items:center;gap:14px;padding:16px;border-radius:18px;background:linear-gradient(130deg,#e9f9ff,#ffffffa8);border:1px solid #d9f3ff;margin-bottom:18px}.account-avatar{width:58px;height:58px;display:grid;place-items:center;border-radius:19px;background:linear-gradient(145deg,#79dcff,#168bd4);color:white;font-size:25px;font-weight:800;box-shadow:0 10px 25px #57c8f14a}.account-hero h2{margin:0;font-size:20px}.account-hero p{margin:2px 0 0;color:var(--muted);font-size:12px}.auth-switch{display:flex;justify-content:center;gap:6px;margin-top:16px;font-size:12px;color:var(--muted)}.auth-switch a{color:#168bd4;font-weight:800}.login-card{box-shadow:0 25px 75px rgba(48,129,173,.15)}.field input:focus,.field textarea:focus,.field select:focus{outline:0;border-color:#48bfe9;box-shadow:0 0 0 4px #48bfe91e}.btn:focus-visible,.admin-link:focus-visible,a:focus-visible{outline:3px solid #79dcff;outline-offset:3px}.footer-inner a:hover{color:#147db4}.notice{overflow-wrap:anywhere}.field input,.field textarea,.field select,.filter-bar input,.filter-bar select{min-height:43px}.brand{min-width:0}.brand>span:last-child{min-width:0}.brand small{max-width:230px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@keyframes opal-enter{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}@media(max-width:650px){.brand-logo{width:38px;height:38px}.brand small{max-width:135px}.desktop-nav a.nav-active{background:#e5f7ff}}@media(prefers-reduced-motion:reduce){.hero-copy,.hero-art,.product-card,.category-tile,.trust-item,.promo{animation:none}.product-card:hover,.btn:hover{transform:none}}\n";
    echo <<<'MOBILECSS'
/* Mobile UX refinement based on the supplied reference */
@media(max-width:650px){
.shell{width:calc(100% - 20px)}.section{padding:18px 0 24px}.section-head{gap:8px;margin-bottom:12px}.section-head h2{font-size:19px;line-height:1.5}
.product-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;align-items:stretch}.product-card{min-width:0;border-radius:15px;overflow:hidden}.product-image{aspect-ratio:1/1;height:auto;min-height:0}.product-image img{width:100%;height:100%;object-fit:cover}.product-content{padding:8px 7px 9px;min-width:0}.product-content h3{font-size:11px;line-height:1.55;margin:0 0 4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;min-height:34px}.product-content p{font-size:9px;line-height:1.5;min-height:27px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin:0 0 7px}.product-kicker{font-size:8px}.price{gap:2px;flex-wrap:wrap}.price strong{font-size:10px;line-height:1.5}.price del{font-size:8px}.product-bottom{padding-top:7px;margin-top:7px;gap:4px;align-items:center}.product-bottom .btn{font-size:9px;padding:6px 7px;border-radius:9px;min-width:0;white-space:nowrap}.round-arrow{width:25px;height:25px;min-width:25px;border-radius:8px}
.category-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.category-tile{padding:9px 6px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:5px;min-width:0}.category-symbol{width:31px;height:31px;font-size:15px;margin:0}.category-tile b{font-size:10px;overflow-wrap:anywhere}.category-tile small{font-size:8px}
.trust-row{grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}.trust-item{padding:9px 6px;text-align:center}.trust-item b{font-size:10px}.trust-item p{font-size:9px;line-height:1.5}
.filter-bar{display:grid;grid-template-columns:1fr 1fr}.filter-bar input,.filter-bar select{width:100%;min-width:0}.filter-bar input:first-child{grid-column:1/-1}.cart-layout{grid-template-columns:minmax(0,1fr);gap:12px}.cart-line{grid-template-columns:48px minmax(0,1fr) auto;gap:8px;padding:10px 0}.cart-line img{width:48px;height:48px}.cart-line>b{font-size:11px;white-space:nowrap}.cart-line input{max-width:64px}
.topbar{width:calc(100% - 12px);padding:7px 8px;gap:5px}.brand{gap:6px}.brand-mark{width:34px;height:34px;font-size:20px}.brand-logo{width:34px;height:34px}.brand b{font-size:15px}.brand small{display:none}.nav-actions{gap:5px}.icon-btn{width:35px;height:35px}.account-link{padding:7px 8px;font-size:10px}.menu-btn{font-size:20px;padding:3px}.footer-inner{grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}.footer-inner a,.footer-inner p{overflow-wrap:anywhere}.page-title{padding:20px 0 10px}.page-title h1{font-size:23px}
}
@media(max-width:390px){.product-grid{gap:6px}.product-content{padding:7px 5px}.product-content h3{font-size:10px;min-height:31px}.product-content p{font-size:8px;min-height:24px}.product-bottom .btn{font-size:8px;padding:6px 5px}.price strong{font-size:9px}.category-grid{gap:5px}.admin-link{display:none}.nav-actions .account-link{display:inline-flex}}
MOBILECSS;
    echo '</style></head><body><div class="ambient ambient-a"></div><div class="ambient ambient-b"></div><header class="topbar glass"><a class="brand" href="?" aria-label="خانه '.h($siteName).'">'.$brandMark.'<span><b>'.h($siteName).'</b><small>'.h($tagline!==''?$tagline:'فروشگاه محصولات دیجیتال').'</small></span></a><nav class="desktop-nav"><a class="'.($page==='home'?'nav-active':'').'" href="?" '.($page==='home'?'aria-current="page"':'').'>خانه</a><a class="'.($page==='products'||$page==='product'?'nav-active':'').'" href="?page=products">محصولات</a><a class="'.($page==='faq'?'nav-active':'').'" href="?page=faq">پرسش‌های متداول</a></nav><div class="nav-actions"><a class="icon-btn" href="?page=cart" aria-label="سبد خرید"><svg viewBox="0 0 24 24"><path d="M3 4h2l2.2 10.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 1.9-1.4L21 8H6"/><circle cx="10" cy="20" r="1"/><circle cx="18" cy="20" r="1"/></svg><span class="cart-count">'.(int)$cartCount.'</span></a>'.(is_customer()?'<a class="admin-link account-link" href="?page=account">حساب من</a>':'<a class="admin-link account-link" href="?page=user-login">ورود کاربران</a>').'<a class="admin-link admin-link-secondary" href="?page=admin">مدیریت</a><button class="menu-btn" type="button" aria-label="باز کردن منو" aria-expanded="false" onclick="document.body.classList.toggle(\'menu-open\');this.setAttribute(\'aria-expanded\',document.body.classList.contains(\'menu-open\'))">☰</button></div></header><main class="shell">';
    if(isset($GLOBALS['flash'])&&$GLOBALS['flash'])echo '<div class="notice '.h($GLOBALS['flash']['type']??'ok').'">'.h($GLOBALS['flash']['message']??'').'</div>';
    if(!empty($GLOBALS['err']))echo '<div class="notice error">'.h($GLOBALS['err']).'</div>';
}
function render_footer(): void {
    global $settings;
    $siteName=trim((string)($settings['site_name']??'Opal')) ?: 'Opal';
    $logo=trim((string)($settings['logo_path']??''));
    $brandMark=$logo!=='' ? '<img class="brand-logo" src="'.h($logo).'" alt="'.h($siteName).'">' : '<span class="brand-mark">'.h(u_substr($siteName,0,1)).'</span>';
    echo '</main><footer class="footer"><div class="footer-inner"><div><a class="brand footer-brand" href="?">'.$brandMark.'<span><b>'.h($siteName).'</b><small>فروشگاه محصولات دیجیتال</small></span></a><p>'.h($settings['description']).'</p></div><div><b>دسترسی سریع</b><a href="?">خانه</a><a href="?page=products">همه محصولات</a><a href="?page=faq">سؤالات متداول</a></div><div><b>پشتیبانی</b><a href="?page=contact">تماس با ما</a><a href="?page=terms">قوانین و مقررات</a><a href="?page=privacy">حریم خصوصی</a></div></div><div class="copyright">© '.date('Y').' '.h($siteName).' — تمامی حقوق محفوظ است.</div></footer><script>document.querySelectorAll("[data-confirm]").forEach(function(el){el.addEventListener("click",function(e){if(!confirm(el.dataset.confirm))e.preventDefault()})});</script></body></html>';
}
function product_card(array $p): void {
    $price=product_price($p);$stock=stock_count($p);
    echo '<article class="product-card glass"><a class="product-image" href="?page=product&id='.rawurlencode((string)$p['id']).'"><img src="'.h(image_url((string)($p['image']??''))).'" alt="'.h($p['name']).'" loading="lazy">'.($stock>0?'<span class="stock-pill">موجود</span>':'<span class="stock-pill out">ناموجود</span>').'</a><div class="product-content"><div class="product-kicker">'.h($p['platform']??'Minecraft').'</div><h3><a href="?page=product&id='.rawurlencode((string)$p['id']).'">'.h($p['name']).'</a></h3><p>'.h(u_substr(strip_tags((string)($p['description']??'')),0,105)).'</p><div class="product-bottom"><div class="price">'.($price<(int)($p['price']??0)?'<del>'.money($p['price']).'</del>':'').'<strong>'.money($price).'</strong></div><a class="round-arrow" href="?page=product&id='.rawurlencode((string)$p['id']).'" aria-label="مشاهده محصول">↙</a></div></div></article>';
}
const CSS = <<<'CSS'
:root{--ink:#122b43;--muted:#6f8294;--blue:#36b9ef;--blue2:#168bd4;--line:rgba(74,155,199,.18);--glass:rgba(255,255,255,.68);--shadow:0 18px 55px rgba(48,129,173,.10);--radius:24px}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:linear-gradient(145deg,#f8fcff 0%,#edf8ff 45%,#f8fcff 100%);color:var(--ink);font-family:Estedad,Vazirmatn,Tahoma,sans-serif;line-height:1.8;min-height:100vh;overflow-x:hidden}a{color:inherit;text-decoration:none}button,input,select,textarea{font:inherit}button,a{ -webkit-tap-highlight-color:transparent}button{cursor:pointer}.ambient{position:fixed;z-index:-1;pointer-events:none;border-radius:50%;filter:blur(75px);opacity:.42}.ambient-a{width:360px;height:360px;background:#a7e9ff;top:-130px;right:-100px}.ambient-b{width:330px;height:330px;background:#c5e5ff;left:-130px;top:45vh}.glass{background:var(--glass);border:1px solid rgba(255,255,255,.88);box-shadow:var(--shadow);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}.topbar{position:sticky;top:12px;z-index:30;width:min(1200px,calc(100% - 28px));margin:12px auto 0;border-radius:22px;padding:10px 18px;display:flex;align-items:center;gap:28px}.brand{display:flex;align-items:center;gap:10px;min-width:max-content}.brand-mark{display:grid;place-items:center;width:44px;height:44px;border-radius:15px;background:linear-gradient(145deg,#79dcff,#168bd4);color:white;font-weight:800;font-size:25px;box-shadow:0 8px 22px #57c8f14a}.brand b{display:block;font-size:19px;line-height:1.2;letter-spacing:.3px}.brand small{display:block;color:var(--muted);font-size:10px;margin-top:3px}.desktop-nav{display:flex;align-items:center;gap:24px;margin:auto;font-size:13px;color:#557085}.desktop-nav a:hover{color:var(--blue2)}.nav-actions{display:flex;align-items:center;gap:10px}.icon-btn{position:relative;width:42px;height:42px;border:1px solid var(--line);background:#fff9;border-radius:14px;display:grid;place-items:center}.icon-btn svg{width:21px;stroke:var(--ink);stroke-width:1.7;fill:none}.cart-count{position:absolute;top:-5px;left:-5px;background:var(--blue2);color:white;border-radius:50%;min-width:19px;height:19px;font-size:10px;display:grid;place-items:center}.admin-link,.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 17px;border-radius:14px;background:linear-gradient(135deg,#48c7f4,#168bd4);color:#fff;font-size:13px;font-weight:700;border:0;box-shadow:0 8px 18px #24a8df2b;transition:transform .2s,box-shadow .2s}.btn:hover,.admin-link:hover{transform:translateY(-2px);box-shadow:0 12px 24px #24a8df3a}.btn.secondary{background:#fff;color:var(--ink);border:1px solid var(--line);box-shadow:none}.btn.danger{background:#fff0f0;color:#b42334;border:1px solid #f4c7cc;box-shadow:none}.btn.small{padding:7px 11px;font-size:12px}.menu-btn{display:none;border:0;background:transparent;font-size:22px;color:var(--ink)}.shell{width:min(1160px,calc(100% - 32px));margin:0 auto;min-height:55vh}.notice{padding:12px 16px;border-radius:15px;margin:16px 0;background:#e6f8ef;color:#176b48;border:1px solid #b9ebd1;font-size:13px}.notice.error{background:#fff0f0;color:#a52b37;border-color:#f3c9cd}.hero{position:relative;display:grid;grid-template-columns:1.1fr .9fr;align-items:center;gap:32px;padding:60px 4px 42px;min-height:430px}.eyebrow{display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:99px;background:#e2f7ff;color:#1688bd;font-size:12px;font-weight:700;border:1px solid #c8efff}.eyebrow:before{content:"";width:6px;height:6px;background:#30bce9;border-radius:50%;box-shadow:0 0 0 4px #bceeff}.hero h1{font-size:clamp(32px,4.5vw,56px);line-height:1.35;letter-spacing:-1.5px;margin:18px 0 14px;font-weight:800}.hero h1 span{color:#168bd4}.hero p{color:var(--muted);max-width:540px;font-size:15px;margin:0 0 25px}.hero-actions{display:flex;gap:10px;flex-wrap:wrap}.hero-art{min-height:320px;position:relative;display:grid;place-items:center}.orb{width:min(340px,85%);aspect-ratio:1;border-radius:34% 66% 57% 43%/40% 41% 59% 60%;background:linear-gradient(145deg,#e3f9ff,#a9e7ff 48%,#65cafa);position:relative;box-shadow:inset 12px 12px 30px #ffffffbd,inset -15px -18px 35px #3aafe866,0 35px 70px #48bde32c;transform:rotate(-8deg)}.orb:before,.orb:after{content:"";position:absolute;border-radius:50%;background:#ffffff6e;filter:blur(1px)}.orb:before{width:72%;height:28%;top:12%;left:12%;transform:rotate(-24deg)}.orb:after{width:45%;height:13%;bottom:16%;right:8%;background:#168bd42b}.cube{position:absolute;width:100px;height:100px;border-radius:27px;background:linear-gradient(140deg,#ffffffd9,#a4e8ffb8);border:1px solid #ffffffef;box-shadow:0 22px 45px #339dcc24;backdrop-filter:blur(8px);display:grid;place-items:center;color:#168bd4;font-size:42px;font-weight:800}.cube.one{top:28px;right:4%;transform:rotate(12deg)}.cube.two{bottom:22px;left:2%;width:75px;height:75px;border-radius:22px;font-size:29px;transform:rotate(-12deg)}.float-card{position:absolute;bottom:38px;right:8%;background:#ffffffc9;border:1px solid #fff;border-radius:16px;padding:10px 15px;box-shadow:var(--shadow);font-size:12px}.float-card b{display:block;color:#168bd4;font-size:15px}.section{padding:30px 0 45px}.section-head{display:flex;align-items:end;justify-content:space-between;gap:16px;margin-bottom:20px}.section-head h2{font-size:25px;margin:0 0 4px}.section-head p{margin:0;color:var(--muted);font-size:13px}.text-link{color:#168bd4;font-size:13px;font-weight:700;white-space:nowrap}.trust-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:0 0 30px}.trust-item{display:flex;gap:12px;align-items:center;padding:16px;border-radius:19px}.trust-icon{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;background:#e3f7ff;color:#168bd4;font-size:21px;flex-shrink:0}.trust-item b{display:block;font-size:13px}.trust-item span{display:block;font-size:11px;color:var(--muted)}.product-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.product-card{border-radius:22px;overflow:hidden;transition:transform .22s,border-color .22s;min-width:0}.product-card:hover{transform:translateY(-4px);border-color:#a9e8ff}.product-image{height:190px;display:block;position:relative;overflow:hidden;background:linear-gradient(135deg,#d9f4ff,#f4fbff)}.product-image img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s}.product-card:hover .product-image img{transform:scale(1.04)}.stock-pill{position:absolute;top:12px;right:12px;background:#e5fff2;color:#17794f;border:1px solid #c0f0d7;border-radius:50px;padding:4px 10px;font-size:10px;font-weight:700}.stock-pill.out{background:#fff0f0;color:#b42334;border-color:#f4c7cc}.product-content{padding:16px}.product-kicker{font-size:10px;color:#168bd4;font-weight:700}.product-content h3{font-size:16px;margin:4px 0 5px;line-height:1.6}.product-content p{font-size:12px;color:var(--muted);margin:0;min-height:42px}.product-bottom{display:flex;align-items:end;justify-content:space-between;gap:10px;border-top:1px solid var(--line);padding-top:13px;margin-top:14px}.price strong{display:block;font-size:15px;color:#126da8}.price del{display:block;color:#91a0ad;font-size:10px}.round-arrow{width:36px;height:36px;border-radius:12px;background:#e5f7ff;color:#168bd4;display:grid;place-items:center;font-size:19px}.category-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px}.category-tile{padding:18px;border-radius:20px;display:flex;align-items:center;gap:12px;min-width:0;transition:transform .2s}.category-tile:hover{transform:translateY(-3px)}.category-symbol{width:42px;height:42px;border-radius:14px;background:#e3f7ff;display:grid;place-items:center;font-size:21px;color:#168bd4;flex-shrink:0}.category-tile b{font-size:13px;display:block;overflow-wrap:anywhere}.category-tile small{font-size:10px;color:var(--muted)}.promo{padding:30px;border-radius:25px;display:flex;align-items:center;justify-content:space-between;gap:24px;background:linear-gradient(120deg,#e7faffd9,#ffffffbd);margin:12px 0 48px}.promo h2{font-size:22px;margin:0 0 4px}.promo p{margin:0;color:var(--muted);font-size:13px}.footer{margin-top:45px;padding:35px max(20px,calc((100% - 1160px)/2)) 18px;border-top:1px solid #cde8f3;background:#ffffff70}.footer-inner{display:grid;grid-template-columns:2fr 1fr 1fr;gap:35px}.footer-inner p{font-size:12px;color:var(--muted);max-width:360px}.footer-inner>div:not(:first-child){display:flex;flex-direction:column;gap:8px;font-size:12px;color:var(--muted)}.footer-inner>div>b{color:var(--ink);margin-bottom:6px}.copyright{text-align:center;border-top:1px solid var(--line);padding-top:15px;margin-top:25px;color:#91a1ad;font-size:10px}.page-title{padding:34px 0 18px}.page-title h1{font-size:31px;margin:0 0 4px}.page-title p{color:var(--muted);margin:0;font-size:13px}.filter-bar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:14px;border-radius:18px;margin-bottom:22px}.field{display:flex;flex-direction:column;gap:6px;margin-bottom:13px;min-width:0}.field label{font-size:12px;font-weight:700;color:#4d667a}.field input,.field textarea,.field select,.input{width:100%;min-width:0;border:1px solid #d6eaf3;background:#ffffffc9;border-radius:13px;padding:11px 12px;outline:none;color:var(--ink);font-size:13px;transition:border .2s,box-shadow .2s}.field textarea{min-height:105px;resize:vertical}.field input:focus,.field textarea:focus,.field select:focus,.input:focus{border-color:#65c8ef;box-shadow:0 0 0 3px #8ddfff2a}.filter-bar input,.filter-bar select{flex:1;min-width:140px;border:1px solid #d6eaf3;background:#fff9;border-radius:12px;padding:10px;font-size:12px;color:var(--ink)}.two-col{display:grid;grid-template-columns:1fr 1fr;gap:14px}.panel{padding:22px;border-radius:22px;margin:15px 0}.panel h2,.panel h3{margin-top:0}.product-detail{display:grid;grid-template-columns:.9fr 1.1fr;gap:30px;padding:28px 0}.detail-image{border-radius:25px;overflow:hidden;align-self:start}.detail-image img{width:100%;display:block;aspect-ratio:1;object-fit:cover}.detail-info h1{font-size:30px;line-height:1.5;margin:8px 0}.detail-info p{color:var(--muted);font-size:14px}.detail-price{font-size:25px;color:#126da8;font-weight:800;margin:20px 0}.detail-meta{display:flex;gap:8px;flex-wrap:wrap}.tag{font-size:11px;border-radius:50px;background:#e5f7ff;color:#247ca8;padding:5px 10px}.buy-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:20px 0}.qty{width:75px!important}.cart-layout{display:grid;grid-template-columns:1.4fr .8fr;gap:18px;align-items:start}.cart-line{display:grid;grid-template-columns:72px 1fr auto;gap:14px;align-items:center;padding:14px 0;border-bottom:1px solid var(--line)}.cart-line img{width:72px;height:72px;object-fit:cover;border-radius:14px}.cart-line h3{font-size:14px;margin:0}.cart-line p{font-size:12px;color:var(--muted);margin:3px 0}.cart-line input{width:64px;padding:7px;border:1px solid var(--line);border-radius:10px}.summary-row{display:flex;justify-content:space-between;gap:12px;font-size:13px;padding:8px 0}.summary-row.total{font-size:17px;font-weight:800;border-top:1px solid var(--line);margin-top:8px;padding-top:15px}.empty{padding:45px 20px;text-align:center;border-radius:24px}.empty .symbol{font-size:42px;color:#55bfe9}.empty h2{margin:5px 0}.empty p{color:var(--muted);font-size:13px}.form-card{max-width:650px;margin:20px auto;padding:25px;border-radius:24px}.admin-layout{display:grid;grid-template-columns:220px 1fr;gap:18px;padding:25px 0}.admin-side{padding:15px;border-radius:22px;align-self:start;position:sticky;top:90px}.admin-side h3{font-size:14px;margin:8px 10px 15px}.admin-side a{display:block;padding:10px 12px;border-radius:12px;font-size:12px;color:#587186;margin:3px 0}.admin-side a:hover,.admin-side a.active{background:#e5f7ff;color:#137db5}.admin-main{min-width:0}.admin-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:18px}.admin-head h1{font-size:24px;margin:0}.stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.stat{padding:17px;border-radius:18px;min-width:0}.stat span{display:block;color:var(--muted);font-size:11px}.stat b{font-size:23px;display:block;overflow-wrap:anywhere}.table-wrap{overflow:auto;border-radius:17px;border:1px solid var(--line);background:#ffffffa6}.data-table{width:100%;border-collapse:collapse;min-width:600px;font-size:12px}.data-table th,.data-table td{padding:12px;text-align:right;border-bottom:1px solid var(--line);vertical-align:middle}.data-table th{background:#edf9ff;color:#4d6a7e;font-weight:700}.data-table tr:last-child td{border-bottom:0}.status{display:inline-block;padding:4px 8px;border-radius:50px;font-size:10px;background:#edf6fa;color:#60798b}.status.paid,.status.delivered{background:#e4faef;color:#1b8055}.status.failed,.status.payment_failed{background:#fff0f0;color:#b42334}.status.pending{background:#fff6df;color:#9b6b0d}.actions{display:flex;gap:6px;flex-wrap:wrap}.admin-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 16px}.admin-form-grid .wide{grid-column:1/-1}.login-wrap{min-height:62vh;display:grid;place-items:center;padding:35px 0}.login-card{width:min(460px,100%);padding:28px;border-radius:25px}.login-card h1{margin:0 0 5px;font-size:25px}.login-card>p{color:var(--muted);font-size:13px;margin:0 0 20px}.help{font-size:11px;color:var(--muted)}.faq-item{padding:17px 20px;border-radius:18px;margin:10px 0}.faq-item h3{font-size:14px;margin:0 0 5px}.faq-item p{font-size:13px;color:var(--muted);margin:0}.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.step{padding:20px;border-radius:20px}.step b{display:block;font-size:15px}.step p{font-size:12px;color:var(--muted);margin-bottom:0}.step-num{width:34px;height:34px;display:grid;place-items:center;background:#e1f7ff;color:#168bd4;border-radius:12px;margin-bottom:12px;font-weight:800}.delivery-box{padding:15px;border-radius:16px;background:#e9fff4;border:1px solid #bdebd3;margin:12px 0;overflow-wrap:anywhere}.delivery-box code{display:block;white-space:pre-wrap;word-break:break-all;background:#fff9;padding:10px;border-radius:10px;margin-top:8px}.small-muted{font-size:11px;color:var(--muted)}@media(max-width:900px){.desktop-nav{gap:12px}.hero{gap:15px}.product-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.category-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.stat-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.admin-layout{grid-template-columns:180px 1fr}.topbar{gap:14px}.hero h1{font-size:39px}}@media(max-width:650px){.topbar{top:7px;margin-top:7px;width:calc(100% - 14px);padding:8px 10px;border-radius:18px;gap:8px}.brand-mark{width:39px;height:39px;border-radius:13px}.brand b{font-size:17px}.brand small{font-size:9px}.desktop-nav{display:none}.menu-btn{display:block}.menu-open .desktop-nav{display:flex;position:absolute;top:calc(100% + 7px);right:0;left:0;flex-direction:column;align-items:stretch;gap:0;padding:8px;border-radius:17px;background:#fffffff2;border:1px solid white;box-shadow:var(--shadow)}.menu-open .desktop-nav a{padding:10px 12px}.nav-actions{margin-right:auto;gap:6px}.admin-link{padding:8px 10px;font-size:11px}.icon-btn{width:38px;height:38px}.shell{width:calc(100% - 24px)}.hero{grid-template-columns:1fr;padding:38px 0 22px;gap:0;min-height:0}.hero h1{font-size:34px;letter-spacing:-.7px;margin:13px 0 10px}.hero p{font-size:13px}.hero-art{min-height:245px;grid-row:1}.orb{width:230px}.cube.one{width:68px;height:68px;border-radius:20px;font-size:30px;top:20px;right:10%}.cube.two{width:57px;height:57px;border-radius:16px;font-size:22px;bottom:14px;left:8%}.float-card{bottom:20px;right:12%;font-size:10px}.float-card b{font-size:12px}.trust-row{grid-template-columns:1fr;gap:8px;margin-bottom:18px}.trust-item{padding:12px}.section{padding:22px 0 28px}.section-head h2{font-size:21px}.section-head p{font-size:11px}.product-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.product-image{height:auto;aspect-ratio:1.2}.product-content{padding:11px}.product-content h3{font-size:13px}.product-content p{font-size:10px;min-height:36px}.product-kicker{font-size:9px}.price strong{font-size:12px}.price del{font-size:9px}.product-bottom{padding-top:10px;margin-top:10px}.round-arrow{width:31px;height:31px;border-radius:10px}.category-grid{gap:8px}.category-tile{padding:11px;gap:8px;border-radius:16px}.category-symbol{width:35px;height:35px;border-radius:11px;font-size:17px}.category-tile b{font-size:11px}.category-tile small{font-size:9px}.promo{padding:20px;display:block;margin-bottom:25px}.promo .btn{margin-top:15px}.footer-inner{grid-template-columns:1fr 1fr;gap:22px}.footer-inner>div:first-child{grid-column:1/-1}.page-title{padding:26px 0 14px}.page-title h1{font-size:25px}.filter-bar{padding:10px;gap:7px}.filter-bar input,.filter-bar select{min-width:calc(50% - 7px);font-size:11px}.product-detail{grid-template-columns:1fr;gap:18px;padding-top:15px}.detail-image img{aspect-ratio:1.2}.detail-info h1{font-size:24px}.detail-info p{font-size:13px}.detail-price{font-size:22px}.cart-layout{grid-template-columns:1fr}.cart-line{grid-template-columns:56px 1fr auto;gap:9px}.cart-line img{width:56px;height:56px}.cart-line h3{font-size:12px}.cart-line p{font-size:10px}.two-col,.admin-form-grid{grid-template-columns:1fr}.admin-form-grid .wide{grid-column:auto}.admin-layout{grid-template-columns:1fr;gap:12px;padding:15px 0}.admin-side{position:static;display:flex;gap:4px;overflow:auto;white-space:nowrap;padding:8px}.admin-side h3{display:none}.admin-side a{padding:8px 10px;margin:0}.admin-head h1{font-size:21px}.stat-grid{gap:8px}.stat{padding:12px}.visit-chart{gap:5px;min-height:160px;padding:10px 0}.visit-bars{height:78px;width:min(24px,85%)}.visit-day b{font-size:11px}.visit-day small,.visit-day em{font-size:9px}.stat b{font-size:19px}.panel{padding:15px}.steps{grid-template-columns:1fr}.form-card{padding:18px}.login-card{padding:21px}.footer{padding-left:16px;padding-right:16px}}@media(max-width:370px){.product-grid{grid-template-columns:1fr}.product-image{aspect-ratio:1.5}.hero h1{font-size:30px}.admin-link{display:none}.category-grid{grid-template-columns:1fr 1fr}}@media(prefers-reduced-motion:reduce){*,*:before,*:after{scroll-behavior:auto!important;transition:none!important;animation:none!important}}
CSS;

if ($page==='sitemap') {
    header('Content-Type: application/xml; charset=utf-8');
    $base=current_url(); echo '<?xml version="1.0" encoding="UTF-8"?>'."\n".'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    foreach(['','?page=products','?page=faq'] as $u)echo '<url><loc>'.h($base.$u).'</loc></url>';
    foreach(public_products() as $p)echo '<url><loc>'.h($base.'?page=product&amp;id='.rawurlencode((string)$p['id'])).'</loc><lastmod>'.h(substr((string)($p['updated_at']??date('c')),0,10)).'</lastmod></url>';
    echo '</urlset>';exit;
}
if ($page==='robots') { header('Content-Type: text/plain; charset=utf-8');echo "User-agent: *\nDisallow: /?page=admin\nDisallow: /?page=cart\nDisallow: /?page=checkout\nSitemap: ".current_url()."?page=sitemap\n";exit; }

if ($page==='admin' || str_starts_with($page,'admin-')) {
    if ($page!=='admin-login' && !is_admin() && all_data('users')) { flash('برای دسترسی به پنل ابتدا وارد شوید.','error'); redirect('?page=admin-login'); }
    if ($page==='admin-login' && is_admin()) redirect('?page=admin');
    render_header('پنل مدیریت');
    if ($page==='admin-login') {
        echo '<section class="login-wrap"><div class="login-card glass"><div class="brand"><span class="brand-mark">O</span><span><b>ورود مدیریت</b><small>Opal Control Center</small></span></div><h1 style="margin-top:20px">خوش برگشتی</h1><p>برای مدیریت فروشگاه وارد حساب مدیر شوید.</p><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="admin_login"><div class="field"><label>نام کاربری</label><input name="username" required autocomplete="username"></div><div class="field"><label>رمز عبور</label><input type="password" name="password" required autocomplete="current-password"></div><button class="btn" style="width:100%">ورود امن به پنل</button></form><p class="help" style="margin-top:15px">ورود فقط برای حساب مدیر فروشگاه مجاز است.</p></div></section>';
    } else {
        $allProducts=all_data('products');$orders=all_data('orders');$paid=array_filter($orders,fn($o)=>in_array($o['payment_status']??'',['paid'],true));
        $adminNav=['admin'=>'نمای کلی','admin-products'=>'محصولات','admin-categories'=>'دسته‌بندی‌ها','admin-orders'=>'سفارش‌ها','admin-settings'=>'تنظیمات'];
        $visitData=all_data('visits');$todayKey=date('Y-m-d');$todayVisits=$visitData['days'][$todayKey]??['views'=>0,'unique'=>[]];$todayUnique=count($todayVisits['unique']??[]);$todayViews=(int)($todayVisits['views']??0);$allViews=(int)($visitData['total_views']??0);$last7=[];for($d=6;$d>=0;$d--){$key=date('Y-m-d',strtotime('-'.$d.' days'));$last7[]=['date'=>$key,'views'=>(int)($visitData['days'][$key]['views']??0),'unique'=>count($visitData['days'][$key]['unique']??[])];}
        echo '<div class="admin-layout"><aside class="admin-side glass"><h3>Opal Admin</h3>';
        foreach($adminNav as $k=>$v)echo '<a class="'.($page===$k?'active':'').'" href="?page='.$k.'">'.h($v).'</a>';
        echo '<form method="post" style="padding:8px"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="logout"><button class="btn secondary small" style="width:100%">خروج امن</button></form></aside><section class="admin-main">';
        if($page==='admin'){
            echo '<div class="admin-head"><div><h1>نمای کلی</h1><span class="small-muted">خلاصه وضعیت واقعی فروشگاه</span></div><a class="btn" href="?page=admin-product-edit">+ افزودن محصول</a></div><div class="stat-grid"><div class="stat glass"><span>بازدیدکنندگان امروز</span><b>'.$todayUnique.'</b><small class="small-muted">بر اساس نشست مرورگر</small></div><div class="stat glass"><span>بازدید صفحه امروز</span><b>'.$todayViews.'</b></div><div class="stat glass"><span>کل بازدید صفحه‌ها</span><b>'.$allViews.'</b></div><div class="stat glass"><span>همه محصولات</span><b>'.count($allProducts).'</b></div><div class="stat glass"><span>منتشرشده</span><b>'.count(array_filter($allProducts,fn($p)=>($p['status']??'')==='published')).'</b></div><div class="stat glass"><span>همه سفارش‌ها</span><b>'.count($orders).'</b></div><div class="stat glass"><span>فروش تأییدشده</span><b style="font-size:16px">'.money(array_sum(array_map(fn($o)=>(int)($o['total']??0),$paid))).'</b></div></div><div class="panel glass"><div class="admin-head"><h2>آمار ۷ روز اخیر</h2><span class="small-muted">بازدید صفحه / بازدیدکنندهٔ یکتا در هر روز</span></div><div class="visit-chart">';foreach($last7 as $stat){$height=max(5,min(100,(int)$stat['views']));echo '<div class="visit-day"><div class="visit-bars"><span class="visit-bar" style="height:'.$height.'%" title="بازدید صفحه: '.$stat['views'].'"></span></div><b>'.$stat['views'].'</b><small>'.h(substr($stat['date'],5)).'</small><em>'.$stat['unique'].' نفر</em></div>';}echo '</div><p class="small-muted">این آمار از زمان فعال‌شدن نسخهٔ دارای آمارگیر جمع می‌شود و آمار تاریخی قبل از آن در دسترس نیست. IP کاربران ذخیره نمی‌شود.</p></div><div class="panel glass"><div class="admin-head"><h2>آخرین سفارش‌ها</h2><a class="text-link" href="?page=admin-orders">مشاهده همه</a></div>';
            admin_orders_table(array_slice($orders,0,8));echo '</div><div class="panel glass"><h2>محصولات با موجودی کم</h2>';
            $low=array_filter($allProducts,fn($p)=>($p['status']??'')==='published'&&stock_count($p)<3);
            if(!$low)echo '<p class="small-muted">در حال حاضر محصولی با موجودی کمتر از ۳ عدد ندارید.</p>';else foreach($low as $p)echo '<p>'.h($p['name']).' — موجودی: '.stock_count($p).'</p>';
            echo '</div>';
        } elseif($page==='admin-products'||$page==='admin-product-edit'){
            if($page==='admin-products'){
                echo '<div class="admin-head"><h1>مدیریت محصولات</h1><a class="btn" href="?page=admin-product-edit">+ محصول جدید</a></div><div class="table-wrap"><table class="data-table"><thead><tr><th>محصول</th><th>قیمت</th><th>موجودی</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>';
                foreach($allProducts as $p)echo '<tr><td>'.h($p['name']).'<div class="small-muted">'.h($p['slug']??'').'</div></td><td>'.money(product_price($p)).'</td><td>'.stock_count($p).'</td><td><span class="status">'.(($p['status']??'')==='published'?'منتشرشده':'پیش‌نویس').'</span></td><td><div class="actions"><a class="btn secondary small" href="?page=admin-product-edit&id='.h($p['id']).'">ویرایش</a><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="delete_product"><input type="hidden" name="id" value="'.h($p['id']).'"><button class="btn danger small" data-confirm="این محصول حذف شود؟">حذف</button></form></div></td></tr>';
                echo '</tbody></table></div>';
            } else {
                $p=$editing??['id'=>'','name'=>'','slug'=>'','description'=>'','details'=>'','category'=>'','platform'=>'Java / Bedrock','price'=>0,'sale_price'=>0,'stock'=>1,'delivery_type'=>'manual','codes'=>[],'image'=>'','status'=>'draft','seo_title'=>'','seo_description'=>''];
                echo '<div class="admin-head"><h1>'.($editing?'ویرایش محصول':'افزودن محصول').'</h1><a class="btn secondary" href="?page=admin-products">بازگشت</a></div><form class="panel glass" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="save_product"><input type="hidden" name="id" value="'.h($p['id']).'"><div class="admin-form-grid"><div class="field"><label>نام محصول</label><input name="name" required value="'.h($p['name']).'"></div><div class="field"><label>Slug</label><input name="slug" value="'.h($p['slug']).'"></div><div class="field"><label>دسته‌بندی</label><select name="category"><option value="">بدون دسته</option>';
                foreach(all_data('categories') as $c)echo '<option value="'.h($c['id']).'" '.(($p['category']??'')===($c['id']??'')?'selected':'').'>'.h($c['name']).'</option>';
                echo '</select></div><div class="field"><label>نسخه / پلتفرم</label><input name="platform" value="'.h($p['platform']).'"></div><div class="field"><label>قیمت (تومان)</label><input type="number" min="0" name="price" required value="'.h($p['price']).'"></div><div class="field"><label>قیمت تخفیف (اختیاری)</label><input type="number" min="0" name="sale_price" value="'.h($p['sale_price']).'"></div><div class="field"><label>موجودی عددی</label><input type="number" min="0" name="stock" value="'.h($p['stock']).'"></div><div class="field"><label>روش تحویل</label><select name="delivery_type"><option value="manual" '.(($p['delivery_type']??'')==='manual'?'selected':'').'>تحویل دستی</option><option value="codes" '.(($p['delivery_type']??'')==='codes'?'selected':'').'>کدهای دیجیتال</option><option value="file" '.(($p['delivery_type']??'')==='file'?'selected':'').'>فایل (نیازمند تکمیل مسیر دانلود)</option></select></div><div class="field"><label>وضعیت انتشار</label><select name="status"><option value="draft" '.(($p['status']??'')!=='published'?'selected':'').'>پیش‌نویس</option><option value="published" '.(($p['status']??'')==='published'?'selected':'').'>منتشرشده</option></select></div><div class="field"><label>تصویر محصول</label><input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif"><span class="help">JPG/PNG/WebP/GIF، حداکثر ۴ مگابایت.</span></div><div class="field wide"><label>توضیحات</label><textarea name="description">'.h($p['description']).'</textarea></div><div class="field wide"><label>جزئیات و شرایط تحویل</label><textarea name="details">'.h($p['details']).'</textarea></div><div class="field wide"><label>کدهای دیجیتال (هر کد در یک خط؛ فقط در روش کد)</label><textarea name="codes" placeholder="CODE-EXAMPLE-001&#10;CODE-EXAMPLE-002"></textarea><span class="help">اگر این فیلد را با کدهای جدید پر کنید، فهرست کدهای قبلی جایگزین می‌شود. اطلاعات واقعی را امن وارد کنید.</span></div><div class="field"><label>عنوان SEO</label><input name="seo_title" value="'.h($p['seo_title']).'"></div><div class="field"><label>توضیحات SEO</label><input name="seo_description" value="'.h($p['seo_description']).'"></div></div><button class="btn">ذخیره محصول</button></form>';
            }
        } elseif($page==='admin-categories'){
            echo '<div class="admin-head"><h1>دسته‌بندی‌ها</h1></div><form class="panel glass" method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="save_category"><div class="two-col"><div class="field"><label>نام دسته</label><input name="name" required></div><div class="field"><label>Slug (اختیاری)</label><input name="slug"></div></div><div class="field"><label>توضیحات</label><input name="description"></div><button class="btn">ایجاد دسته‌بندی</button></form><div class="table-wrap"><table class="data-table"><thead><tr><th>نام</th><th>Slug</th><th>عملیات</th></tr></thead><tbody>';
            foreach($categories as $c)echo '<tr><td>'.h($c['name']).'</td><td>'.h($c['slug']).'</td><td><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="delete_category"><input type="hidden" name="id" value="'.h($c['id']).'"><button class="btn danger small" data-confirm="دسته حذف شود؟">حذف</button></form></td></tr>';
            echo '</tbody></table></div>';
        } elseif($page==='admin-orders'){
            echo '<div class="admin-head"><h1>سفارش‌ها</h1></div><div class="table-wrap">';admin_orders_table($orders);echo '</div><p class="help">وضعیت پرداخت فقط با پاسخ معتبر تأیید درگاه تغییر می‌کند؛ مدیر امکان تأیید دستی پرداخت ندارد.</p>';
        } else {
            $s=settings();
            echo '<div class="admin-head"><h1>تنظیمات فروشگاه</h1></div><form class="panel glass" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="save_settings"><div class="admin-form-grid">';
            foreach(['site_name'=>'نام فروشگاه','tagline'=>'شعار کوتاه','description'=>'توضیحات فروشگاه','seo_title'=>'عنوان SEO','seo_description'=>'توضیحات SEO','contact_email'=>'ایمیل تماس','contact_phone'=>'شماره تماس','telegram'=>'لینک تلگرام','instagram'=>'لینک اینستاگرام','shipping_note'=>'توضیح تحویل'] as $k=>$label)echo '<div class="field"><label>'.h($label).'</label><input name="'.h($k).'" value="'.h($s[$k]??'').'"></div>';
            echo '<div class="field wide brand-settings"><label>لوگوی نوار بالا و فوتر (JPG، PNG، WebP یا GIF؛ حداکثر ۴ مگابایت)</label><input type="file" name="logo_upload" accept="image/jpeg,image/png,image/webp,image/gif">'.(!empty($s['logo_path'])?'<div class="brand-preview"><img src="'.h($s['logo_path']).'" alt="پیش‌نمایش لوگو"><span>لوگوی فعلی</span><label><input type="checkbox" name="remove_logo_path" value="1"> حذف لوگوی فعلی</label></div>':'<p class="help">در صورت خالی بودن، حرف اول نام فروشگاه نمایش داده می‌شود.</p>').'</div><div class="field wide brand-settings"><label>Favicon سایت (آیکون تب مرورگر؛ JPG، PNG، WebP یا GIF؛ حداکثر ۴ مگابایت)</label><input type="file" name="favicon_upload" accept="image/jpeg,image/png,image/webp,image/gif">'.(!empty($s['favicon_path'])?'<div class="brand-preview"><img class="favicon-preview" src="'.h($s['favicon_path']).'" alt="پیش‌نمایش favicon"><span>Favicon فعلی</span><label><input type="checkbox" name="remove_favicon_path" value="1"> حذف Favicon فعلی</label></div>':'<p class="help">پس از ذخیره، آیکون در تب مرورگر نمایش داده می‌شود.</p>').'</div><div class="field wide"><label>درباره فروشگاه</label><textarea name="about">'.h($s['about']).'</textarea></div><div class="field wide"><label>کلید API Rialit (خالی = بدون تغییر)</label><input type="password" name="rialit_api_key" autocomplete="new-password" placeholder="'.(rialit_api_key_value($s)!==''?'کلید API ذخیره شده است؛ برای تغییر مقدار جدید وارد کنید':'کلید API Rialit را وارد کنید').'"> <span class="help">کلید API فقط در سمت سرور استفاده می‌شود؛ آن را در کد فرانت‌اند یا برای مشتریان نمایش ندهید.</span></div><div class="field wide"><label>Webhook URL درگاه Rialit</label><input type="url" readonly value="'.h(rialit_webhook_url($s)).'" onclick="this.select()"><span class="help">این آدرس را در پنل Rialit به‌عنوان Webhook ثبت کنید. رویدادهای پرداخت باید به همین نشانی POST شوند.</span></div><div class="field"><label>فعال‌سازی پرداخت</label><select name="payment_enabled"><option value="0" '.((($s['payment_enabled']??'0')!=='1'&&(rialit_api_key_value($s)===''||($s['payment_explicitly_disabled']??'')==='1'))?'selected':'').'>غیرفعال</option><option value="1" '.((($s['payment_enabled']??'0')==='1'||(rialit_api_key_value($s)!==''&&($s['payment_explicitly_disabled']??'')!=='1'))?'selected':'').'>فعال</option></select></div><div class="field"><label>حالت درگاه</label><select name="payment_mode"><option value="normal" selected>Rialit واقعی (Production)</option></select><span class="help">درخواست به API اصلی Rialit ارسال می‌شود؛ API Key معتبر و IP سرور مجاز لازم است.</span></div><div class="field wide"><label>آدرس بازگشت پس از پرداخت (برای پنل Rialit، در صورت پشتیبانی)</label><input type="url" name="payment_callback_url" readonly value="'.h(current_url().'?page=payment-callback').'" onclick="this.select()"><span class="help">در صورت وجود گزینه Return URL در پنل Rialit، این آدرس را ثبت کنید. تأیید سفارش در هر صورت فقط با استعلام سرور انجام می‌شود.</span></div><div class="field wide"><div class="notice">API: https://api.rialit.io/api/v1/send — صفحه پرداخت: https://pay.rialit.io/v1/{token} — وب‌هوک: '.h(rialit_webhook_url($s)).' — وضعیت پرداخت از API سرور Rialit بررسی می‌شود.</div></div></div><button class="btn">ذخیره تنظیمات</button></form><form class="panel glass" method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="change_password"><h2>تغییر رمز عبور</h2><div class="two-col"><div class="field"><label>رمز جدید (حداقل ۱۲ کاراکتر)</label><input type="password" name="new_password" required minlength="12"></div><div class="field"><label>تکرار رمز جدید</label><input type="password" name="confirm_password" required minlength="12"></div></div><button class="btn secondary">تغییر رمز</button></form>';
        }
        echo '</section></div>';
    }
    render_footer();exit;
}
function admin_orders_table(array $orders): void {
    echo '<table class="data-table"><thead><tr><th>سفارش</th><th>مشتری</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th><th>جزئیات</th></tr></thead><tbody>';
    foreach($orders as $o){$status=(string)($o['status']??'pending');$label=['pending'=>'در انتظار پرداخت','paid'=>'پرداخت‌شده','delivered'=>'تحویل‌شده','payment_failed'=>'پرداخت ناموفق','cancelled'=>'لغوشده'][$status]??$status;
        echo '<tr><td>'.h($o['number']??$o['id']).'</td><td>'.h($o['customer']['name']??'—').'<div class="small-muted">'.h($o['customer']['email']??'').'</div></td><td>'.money($o['total']??0).'</td><td><span class="status '.h($status).'">'.h($label).'</span></td><td>'.h(substr((string)($o['created_at']??''),0,10)).'</td><td><a class="btn secondary small" href="?page=order&id='.rawurlencode((string)$o['id']).'">مشاهده</a></td></tr>';
    }echo '</tbody></table>';
}

$publicPages=['home','products','product','cart','checkout','order','faq','contact','about','terms','privacy','user-login','register','account'];
if (!in_array($page,$publicPages,true) || ($page==='product' && !$selectedProduct) || ($page==='order' && !$order)) http_response_code(404);
render_header(match($page){'user-login'=>'ورود کاربران','register'=>'ساخت حساب کاربری','account'=>'حساب کاربری','products'=>'محصولات','product'=>$selectedProduct['name']??'محصول','cart'=>'سبد خرید','checkout'=>'تسویه‌حساب','order'=>'جزئیات سفارش','faq'=>'پرسش‌های متداول','contact'=>'تماس با ما','about'=>'درباره ما','terms'=>'قوانین','privacy'=>'حریم خصوصی',default=>'فروشگاه محصولات دیجیتال Minecraft'});
if($page==='user-login'){
    echo '<section class="login-wrap"><div class="login-card glass"><div class="brand"><span class="brand-mark">O</span><span><b>ورود کاربران</b><small>حساب کاربری Opal</small></span></div><h1 style="margin-top:22px">خوش برگشتی 👋</h1><p>برای دسترسی به حساب خود، نام کاربری و رمز عبورت را وارد کن.</p><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="user_login"><div class="field"><label>نام کاربری</label><input name="username" required minlength="3" maxlength="32" autocomplete="username" placeholder="نام کاربری"></div><div class="field"><label>رمز عبور</label><input type="password" name="password" required autocomplete="current-password" placeholder="رمز عبور"></div><button class="btn" style="width:100%">ورود به حساب</button></form><div class="auth-switch">حساب نداری؟ <a href="?page=register">ثبت‌نام کن</a></div></div></section>';
} elseif($page==='register'){
    echo '<section class="login-wrap"><div class="login-card glass"><div class="brand"><span class="brand-mark">O</span><span><b>عضویت در Opal</b><small>ساخت حساب کاربری</small></span></div><h1 style="margin-top:22px">حساب خودت را بساز</h1><p>نام کاربری و رمز عبورت را وارد کن؛ رمز را برای تأیید دوباره بنویس.</p><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="register_user"><div class="field"><label>نام کاربری انگلیسی</label><input name="username" required minlength="3" maxlength="32" pattern="[A-Za-z0-9_.-]+" autocomplete="username" placeholder="مثلاً Ali_123"></div><div class="field"><label>رمز عبور</label><input type="password" name="password" required minlength="8" maxlength="200" autocomplete="new-password" placeholder="حداقل ۸ کاراکتر"></div><div class="field"><label>تکرار رمز عبور</label><input type="password" name="confirm_password" required minlength="8" maxlength="200" autocomplete="new-password" placeholder="رمز عبور را دوباره وارد کن"></div><button class="btn" style="width:100%">ساخت حساب کاربری</button><p class="help" style="margin-top:12px">رمز عبور به‌صورت هش‌شده ذخیره می‌شود و متن اصلی آن ذخیره نمی‌شود.</p></form><div class="auth-switch">قبلاً ثبت‌نام کرده‌ای؟ <a href="?page=user-login">وارد شو</a></div></div></section>';
} elseif($page==='account'){
    if(!is_customer())redirect('?page=user-login');
    $me=current_user();
    echo '<section class="page-title"><h1>حساب کاربری</h1><p>اطلاعات حساب خود را اینجا مشاهده کن.</p></section><div class="account-card glass"><div class="account-hero"><div class="account-avatar">'.h(u_substr((string)($me['username']??'U'),0,1)).'</div><div><h2>'.h($me['username']??'کاربر Opal').'</h2><p>عضو Opal از '.h(substr((string)($me['created_at']??date('Y-m-d')),0,10)).'</p></div></div><div class="summary-row"><span>نام کاربری</span><b>'.h($me['username']??'').'</b></div><div class="summary-row"><span>نوع حساب</span><b>کاربر</b></div><div class="summary-row"><span>وضعیت</span><b>فعال</b></div><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px"><a class="btn" href="?page=products">مشاهده محصولات</a><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="user_logout"><button class="btn secondary">خروج از حساب</button></form></div></div>';
} elseif($page==='home'){
    echo '<section class="hero"><div class="hero-copy"><span class="eyebrow">سایت در حال آپدیت است !</span><h1><span> Opal </span>جایی که میتونی با خیال راحت خرید کنی !</h1><p>'.h($settings['tagline']).' که میتونی با بهترین قیمت , محصولت رو با بهترین کیفیت بخری  </p><div class="hero-actions"><a class="btn" href="?page=products">دیدن محصولات <span>←</span></a></div></div><div class="hero-art"><div class="orb"></div><div class="cube one">✦</div><div class="cube two">◈</div><div class="float-card">تعداد خرید موفق<b>0 عدد</b></div></div></section><div class="trust-row"><div class="trust-item glass"><div class="trust-icon">◇</div><div><b>ارزان</b><span>توی این شرایط اقتصادی حواسمون بهتون هست !</span></div></div><div class="trust-item glass"><div class="trust-icon">↯</div><div><b>امن و با کیفیت</b><span>تمام محصولات Opal ایمن و بدون احتمال بن یا بلاک شدن هستند .</span></div></div><div class="trust-item glass"><div class="trust-icon">⌁</div><div><b>تحویل سریع</b><span>زیر 30 دقیقه محصول تو دستته !</span></div></div></div>';
    if($categories){echo '<section class="section"><div class="section-head"><div><h2>دسته‌بندی‌ها</h2><p>سریع‌تر به محصول موردنظرت برس.</p></div><a class="text-link" href="?page=products">همه محصولات ←</a></div><div class="category-grid">';foreach(array_slice($categories,0,8) as $c)echo '<a class="category-tile glass" href="?page=products&category='.rawurlencode((string)$c['id']).'"><span class="category-symbol">◇</span><span><b>'.h($c['name']).'</b><small>'.count(array_filter($products,fn($p)=>($p['category']??'')===($c['id']??''))).' محصول</small></span></a>';echo '</div></section>';}
    echo '<section class="section"><div class="section-head"><div><h2>محصولات منتخب</h2><p>محصولات منتشرشده فروشگاه</p></div><a class="text-link" href="?page=products">مشاهده همه ←</a></div>';
    if($products){echo '<div class="product-grid">';foreach(array_slice($products,0,6) as $p)product_card($p);echo '</div>';}else echo '<div class="empty glass"><div class="symbol">◇</div><h2>به‌زودی محصولات اینجا قرار می‌گیرند</h2><p>مدیر فروشگاه می‌تواند از پنل مدیریت محصول ثبت و منتشر کند.</p><a class="btn" href="?page=admin">ورود به مدیریت</a></div>';
    echo '</section><section class="promo glass"><div><h2>قبل از خرید، با خیال راحت بررسی کن !</h2><p></p></div><a class="btn" href="?page=faq">پرسش‌های متداول</a></section>';
} elseif($page==='products'){
    echo '<section class="page-title"><h1>همه محصولات</h1><p>محصولات منتشرشده را جست‌وجو و بر اساس نیازت مرتب کن.</p></section><form class="filter-bar glass" method="get"><input type="hidden" name="page" value="products"><input name="q" placeholder="جست‌وجوی محصول..." value="'.h($search).'"><select name="category"><option value="">همه دسته‌ها</option>';
    foreach($categories as $c)echo '<option value="'.h($c['id']).'" '.($categoryFilter===($c['id']??'')?'selected':'').'>'.h($c['name']).'</option>';
    echo '</select><select name="sort"><option value="new">جدیدترین</option><option value="price_asc" '.(($_GET['sort']??'')==='price_asc'?'selected':'').'>ارزان‌ترین</option><option value="price_desc" '.(($_GET['sort']??'')==='price_desc'?'selected':'').'>گران‌ترین</option></select><button class="btn">اعمال فیلتر</button></form>';
    if($visibleProducts){echo '<div class="product-grid">';foreach($visibleProducts as $p)product_card($p);echo '</div>';}else echo '<div class="empty glass"><div class="symbol">⌕</div><h2>محصولی پیدا نشد</h2><p>عبارت جست‌وجو یا فیلتر دسته‌بندی را تغییر بده.</p><a class="btn secondary" href="?page=products">پاک‌کردن فیلترها</a></div>';
} elseif($page==='product'){
    if(!$selectedProduct){echo '<div class="empty glass"><h2>محصول پیدا نشد</h2><a class="btn" href="?page=products">بازگشت به محصولات</a></div>';}
    else {$p=$selectedProduct;$price=product_price($p);echo '<div class="product-detail"><div class="detail-image glass"><img src="'.h(image_url((string)($p['image']??''))).'" alt="'.h($p['name']).'"></div><div class="detail-info"><div class="detail-meta"><span class="tag">'.h($p['platform']??'Minecraft').'</span><span class="tag">'.(stock_count($p)>0?'موجود':'ناموجود').'</span></div><h1>'.h($p['name']).'</h1><p>'.nl2br(h($p['description'])).'</p><div class="detail-price">'.money($price).($price<(int)$p['price']?' <del style="font-size:14px;color:#94a4b0">'.money($p['price']).'</del>':'').'</div><p>'.nl2br(h($p['details']??'')).'</p><p class="small-muted">'.h($settings['shipping_note']).'</p><div class="buy-row"><form method="post" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="add_cart"><input type="hidden" name="id" value="'.h($p['id']).'"><input class="input qty" type="number" name="qty" min="1" max="'.max(1,min(10,stock_count($p))).'" value="1" '.(stock_count($p)<1?'disabled':'').'><button class="btn" '.(stock_count($p)<1?'disabled':'').'>افزودن به سبد خرید</button></form></div><div class="panel glass"><b>پیش از خرید</b><p class="small-muted">نسخه و شرایط سازگاری محصول را بررسی کنید. خرید تنها پس از تأیید سمت سرور پردازش می‌شود.</p></div></div></div><script type="application/ld+json">'.json_encode(['@context'=>'https://schema.org/','@type'=>'Product','name'=>$p['name'],'description'=>strip_tags((string)$p['description']),'image'=>image_url((string)($p['image']??'')),'offers'=>['@type'=>'Offer','price'=>(string)$price,'priceCurrency'=>'IRR','availability'=>stock_count($p)>0?'https://schema.org/InStock':'https://schema.org/OutOfStock','url'=>current_url().'?page=product&id='.$p['id']]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).'</script>';}
} elseif($page==='cart'){
    echo '<section class="page-title"><h1>سبد خرید</h1><p>قبل از ادامه، تعداد و مبلغ محصولات را بررسی کن.</p></section>';
    if(!$cart)echo '<div class="empty glass"><div class="symbol">⌑</div><h2>سبد خریدت خالی است</h2><p>از میان محصولات منتشرشده، محصول مناسب خودت را انتخاب کن.</p><a class="btn" href="?page=products">رفتن به فروشگاه</a></div>';
    else {$sum=0;echo '<div class="cart-layout"><form class="panel glass" method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="update_cart">';
        foreach($cart as $id=>$qty){$p=product_by_id((string)$id);if(!$p||($p['status']??'')!=='published')continue;$line=product_price($p)*(int)$qty;$sum+=$line;echo '<div class="cart-line"><img src="'.h(image_url((string)($p['image']??''))).'" alt=""><div><h3>'.h($p['name']).'</h3><p>'.money(product_price($p)).'</p><input type="number" name="qty['.h($id).']" min="0" max="10" value="'.(int)$qty.'"><span class="small-muted"> صفر = حذف</span></div><b>'.money($line).'</b></div>';}
        echo '<button class="btn secondary" style="margin-top:15px">به‌روزرسانی سبد</button></form><aside class="panel glass"><h2>خلاصه سفارش</h2><div class="summary-row"><span>جمع محصولات</span><b>'.money($sum).'</b></div><div class="summary-row total"><span>مبلغ قابل پرداخت</span><b>'.money($sum).'</b></div><a class="btn" style="width:100%;margin-top:15px" href="?page=checkout">ادامه و ثبت سفارش</a><p class="help">قیمت نهایی هنگام ثبت سفارش در سمت سرور دوباره بررسی می‌شود.</p></aside></div>';}
} elseif($page==='checkout'){
    $cart=$_SESSION['cart']??[];$sum=0;foreach($cart as $id=>$q){$p=product_by_id((string)$id);if($p)$sum+=product_price($p)*(int)$q;}
    echo '<section class="page-title"><h1>ثبت سفارش</h1><p>اطلاعات تماس برای پیگیری سفارش و تحویل دیجیتال لازم است.</p></section>';
    if(!$cart)echo '<div class="empty glass"><h2>سبد خرید خالی است</h2><a class="btn" href="?page=products">مشاهده محصولات</a></div>';
    else echo '<div class="cart-layout"><form class="panel glass" method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="checkout"><div class="field"><label>نام و نام خانوادگی</label><input name="customer_name" required autocomplete="name"></div><div class="two-col"><div class="field"><label>ایمیل</label><input type="email" name="email" required autocomplete="email"></div><div class="field"><label>شماره تماس</label><input name="phone" required autocomplete="tel"></div></div><div class="field"><label>کد تخفیف (در صورت وجود)</label><input name="discount_code" placeholder="کد تخفیف"></div><button class="btn">ثبت سفارش</button><p class="help">با ثبت سفارش، قوانین خرید و تحویل دیجیتال را می‌پذیرید.</p></form><aside class="panel glass"><h2>خلاصه</h2><div class="summary-row"><span>جمع کل</span><b>'.money($sum).'</b></div><div class="summary-row total"><span>مبلغ سفارش</span><b>'.money($sum).'</b></div></aside></div>';
} elseif($page==='order'){
    if(!$order){echo '<div class="empty glass"><h2>سفارش پیدا نشد</h2><p>شناسه سفارش معتبر نیست یا دسترسی ندارید.</p><a class="btn" href="?page=products">بازگشت به فروشگاه</a></div>';}
    else {
        $isOwner=isset($_SESSION['last_order'])&&hash_equals((string)$_SESSION['last_order'],(string)$order['id']);
        if(!is_admin()&&!$isOwner){echo '<div class="empty glass"><h2>دسترسی به این سفارش ممکن نیست</h2><p>برای حفاظت از اطلاعات مشتری، جزئیات سفارش فقط از نشست ثبت‌کننده یا پنل مدیر قابل مشاهده است.</p><a class="btn" href="?page=products">بازگشت به فروشگاه</a></div>';}
        else {
            echo '<section class="page-title"><h1>سفارش '.h($order['number']??'').'</h1><p>تاریخ ثبت: '.h(substr((string)$order['created_at'],0,16)).'</p></section><div class="panel glass"><div class="summary-row"><span>وضعیت سفارش</span><b>'.h(['pending'=>'در انتظار پرداخت','paid'=>'پرداخت‌شده','delivered'=>'تحویل‌شده','payment_failed'=>'پرداخت ناموفق'][$order['status']??'']??$order['status']).'</b></div><div class="summary-row"><span>مبلغ</span><b>'.money($order['total']).'</b></div><div class="summary-row"><span>ایمیل</span><b>'.h($order['customer']['email']??'').'</b></div><h3>محصولات سفارش</h3>';
            foreach($order['items'] as $line)echo '<div class="summary-row"><span>'.h($line['name']).' × '.(int)$line['qty'].'</span><b>'.money($line['line_total']).'</b></div>';
            if(($order['payment_status']??'')!=='paid'){
                echo '<form class="payment-coming-note" method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="create_payment"><input type="hidden" name="order_id" value="'.h($order['id']).'"><button type="submit" class="btn payment-trigger">پرداخت سفارش 🛒</button></form>';
            }
            if(!empty($order['delivered'])){echo '<h3>اطلاعات تحویل</h3>';foreach($order['delivery'] as $d){echo '<div class="delivery-box"><b>'.h($d['product']).'</b><p>'.h($d['message']??'').'</p>';if(!empty($d['values']))foreach($d['values'] as $v)echo '<code>'.h($v).'</code>';echo '</div>';}}
            echo '</div>';
        }
    }
} elseif($page==='faq'){    echo '<section class="page-title"><h1>پرسش‌های متداول</h1><p>پاسخ پرسش‌های رایج درباره خرید دیجیتال.</p></section>';
    foreach([['چطور سفارش را پیگیری کنم؟','پس از ثبت سفارش، لینک جزئیات سفارش نمایش داده می‌شود. آن را در همین نشست نگه دارید.'],['چه زمانی محصول تحویل می‌شود؟','تحویل فقط بعد از تأیید معتبر پرداخت آغاز می‌شود. بعضی محصولات ممکن است به بررسی دستی مدیر نیاز داشته باشند.'],['آیا همه محصولات همیشه موجود هستند؟','خیر. موجودی از پنل مدیریت کنترل می‌شود و ممکن است تغییر کند.'],['اگر پرداخت ناموفق بود چه کنم؟','شماره سفارش را نگه دارید و برای بررسی با پشتیبانی تماس بگیرید. اگر مبلغ کسر شده، دوباره پرداخت نکنید تا وضعیت بررسی شود.'],['آیا محصولات رسمی Minecraft هستند؟','برچسب و شرایط هر محصول را بررسی کنید. Opal نباید محصولی را بدون مجوز یا منشأ معتبر عرضه کند.']] as $f)echo '<div class="faq-item glass"><h3>'.h($f[0]).'</h3><p>'.h($f[1]).'</p></div>';
} elseif($page==='about'){
    echo '<section class="page-title"><h1>درباره Opal</h1></section><div class="panel glass"><p>'.nl2br(h($settings['about'])).'</p></div>';
} elseif($page==='contact'){
    echo '<section class="page-title"><h1>تماس با ما</h1><p>برای پیگیری سفارش، شماره سفارش را همراه پیام خود آماده داشته باشید.</p></section><div class="panel glass">';
    if($settings['contact_email']!=='')echo '<p>ایمیل: <a class="text-link" href="mailto:'.h($settings['contact_email']).'">'.h($settings['contact_email']).'</a></p>';
    if($settings['contact_phone']!=='')echo '<p>تلفن: '.h($settings['contact_phone']).'</p>';
    if($settings['telegram']!=='')echo '<p><a class="text-link" target="_blank" rel="noopener" href="'.h($settings['telegram']).'">تلگرام پشتیبانی ←</a></p>';
    if($settings['contact_email']===''&&$settings['contact_phone']===''&&$settings['telegram']==='')echo '<p>اطلاعات تماس هنوز توسط مدیر ثبت نشده است.</p>';
    echo '</div>';
} elseif($page==='terms'){
    echo '<section class="page-title"><h1>قوانین و مقررات</h1></section><div class="panel glass"><p>پیش از پرداخت، مشخصات، نسخه سازگار، روش تحویل و محدودیت‌های هر محصول را مطالعه کنید. مسئولیت ارائه اطلاعات تماس صحیح بر عهده خریدار است. سفارش پس از ثبت در سیستم ذخیره می‌شود و وضعیت پرداخت فقط پس از تأیید سمت سرور تغییر می‌کند.</p><p>فروشگاه باید فقط محصولات مجاز و دارای منشأ معتبر عرضه کند. قوانین نهایی را پیش از راه‌اندازی عمومی با شرایط کسب‌وکار و قوانین محل فعالیت خود تطبیق دهید.</p></div>';
} elseif($page==='privacy'){
    echo '<section class="page-title"><h1>حریم خصوصی</h1></section><div class="panel glass"><p>برای ثبت و پیگیری سفارش، اطلاعات تماس لازم دریافت می‌شود. اطلاعات سفارش در فایل‌های JSON روی سرور ذخیره می‌شود و نباید در دسترس عمومی قرار گیرد. اطلاعات حساس پرداخت یا PIN درگاه نباید در URL، مرورگر یا لاگ ثبت شود.</p></div>';
} else {
    echo '<div class="empty glass"><div class="symbol">404</div><h2>این صفحه پیدا نشد</h2><p>ممکن است آدرس تغییر کرده باشد.</p><a class="btn" href="?">بازگشت به خانه</a></div>';
}
render_footer();
